import os
import pickle

Telegram_Token = ""

Database_Path = f"{os.path.dirname(__file__)}"
Admins_Database_Name = 'admin.db'

TELEGRAM_SUPPORT_CHAT_ID_PICKLE = os.path.join(os.path.dirname(__file__), "pickles/chat_id.pickle")

def TELEGRAM_SUPPORT_CHAT_ID():
    return (pickle.load(open(TELEGRAM_SUPPORT_CHAT_ID_PICKLE, 'rb')))


WELCOME_MESSAGE = "Привет, это бот поддержки, напиши вопрос, тебе ответит модератор"
WRONG_REPLY = os.getenv("WRONG_REPLY", "WRONG_REPLY")


if not os.path.exists(TELEGRAM_SUPPORT_CHAT_ID_PICKLE):
    with open(TELEGRAM_SUPPORT_CHAT_ID_PICKLE, 'wb') as f:
        value = 0
        pickle.dump(value, f)
