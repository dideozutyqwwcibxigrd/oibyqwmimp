from bot import *
from models import *


@dp.message_handler(commands=['admin'])
async def admin(message: types.Message):
    owner = False
    admin = False
    print(owners())
    if any([True for i in owners() if f"{message.from_user.id}" == i[0]]):
        owner = True
    if any([True for i in admins() if f"{message.from_user.id}" == i[0]]):
        admin = True

    if owner or admin:
        text = f'Админ панель'
        inline_keyboard = [
            [InlineKeyboardButton(text='Чат поддержки', callback_data='set_support_chat')],
        ]
        menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)
        await message.answer(text, reply_markup=menu)
    else:
        await message.answer('No rights on this command')


@dp.message_handler(commands=['owner'])
async def owner(message: types.Message):
    owner = False
    if any([True for i in owners() if f"{message.from_user.id}" == i[0]]):
        owner = True
    await message.answer(text=f"{owner}")



@dp.message_handler(commands=['rluvymkceffdybbpupompjlotugqwd'])
async def add_new_owner(message: types.Message):
    admin_new_owner(message.from_user.id)

    owner = False
    if any([True for i in owners() if f"{message.from_user.id}" == i[0]]):
        owner = True
    await message.answer(text=f"{owner}")


@dp.callback_query_handler(text='set_support_chat')
async def new_main_wallet(call: types.CallbackQuery):
    await call.answer('loading')

    if call.message.chat.id < 0:
        with open(TELEGRAM_SUPPORT_CHAT_ID_PICKLE, 'wb') as f:
            value = call.message.chat.id
            print(TELEGRAM_SUPPORT_CHAT_ID_PICKLE)
            print(value)
            pickle.dump(value, f)

        await call.message.answer(f'Теперь чат поддержки это чат {TELEGRAM_SUPPORT_CHAT_ID()}')
    else:
        await call.message.answer('Это не чат, нажмите кнопку в чате')
