import sqlite3
import datetime

from bot import *
from config import *


class Database:
    def __init__(self, main_path, database):
        if os.path.exists(main_path):
            self.main_path = main_path
        else:
            raise FileExistsError
        self.database = database

    def sql_table_list(self):
        con = sqlite3.connect(os.path.join(self.main_path, f"{self.database}"))
        cur = con.cursor()
        table_list = []
        for i in cur.execute(f"""SELECT name FROM sqlite_master WHERE type='table'""").fetchall():
            # cur.execute(f"""DROP TABLE IF EXISTS {i[0]}""")
            table_list.append(i[0])
        return table_list

    def sql_create_table(self, table_name: str, columns: list):
        con = sqlite3.connect(os.path.join(self.main_path, f"{self.database}"))
        cur = con.cursor()
        # check if table already exist
        res = [i[0] for i in cur.execute(f"""SELECT name FROM sqlite_master WHERE type='table'""").fetchall()]
        if table_name in res:
            return False
        else:
            cur.execute(f"""CREATE TABLE {table_name} ({', '.join([str(i) for i in columns])})""")
            return True

    def sql_drop_table(self, table_name: str):
        con = sqlite3.connect(os.path.join(self.main_path, f"{self.database}"))
        cur = con.cursor()
        # check if table already exist
        if table_name == 'all':
            for i in cur.execute(f"""SELECT name FROM sqlite_master WHERE type='table'""").fetchall():
                cur.execute(f"""DROP TABLE IF EXISTS {i[0]}""")
        else:
            res = [i[0] for i in cur.execute(f"""DROP TABLE IF EXISTS {table_name}""").fetchall()]

    def sql_get_from_table(self, table_name, columns='*'):
        con = sqlite3.connect(os.path.join(self.main_path, f"{self.database}"))
        cur = con.cursor()
        res = [i[0] for i in cur.execute(f"""SELECT name FROM sqlite_master WHERE type='table'""").fetchall()]
        if table_name in res:
            if columns == '*':
                result = [i for i in cur.execute(f"""SELECT {columns} FROM {table_name}""").fetchall()]
                return result
            result = [i for i in cur.execute(
                f"""SELECT {", ".join([str(i) for i in columns])} FROM {table_name}""").fetchall()]
            return result
        else:
            return False

    def sql_insert_into_table(self, table, insert_info: list):
        con = sqlite3.connect(os.path.join(self.main_path, f"{self.database}"))
        cur = con.cursor()

        cur.execute(f"""INSERT INTO {table} VALUES ({('?, '*len(insert_info))[:-2]})""", insert_info)
        result = [i for i in cur.execute(f"""SELECT * FROM {table}""")]
        con.commit()
        con.close()
        return result

    def sql_del_from_table(self, table, delete_info):
        con = sqlite3.connect(os.path.join(self.main_path, f"{self.database}"))
        cur = con.cursor()

        cur.execute(f"""DELETE FROM {table} WHERE {delete_info[0]} = '{delete_info[1]}'""")

        result = [i for i in cur.execute(f"""SELECT * FROM {table}""")]
        con.commit()
        con.close()
        return result


# ________________________________ admin database ________________________________
def New_Admin_Database():
    db = Database(Database_Path, Admins_Database_Name)
    db.sql_drop_table('all')
    # error
    db.sql_create_table('admin', ['telegram_id', 'time'])
    db.sql_create_table('owner', ['telegram_id', 'time'])
    db.sql_create_table('btc_wallets', ['address', 'time'])
    db.sql_create_table('rub_wallets', ['card_number', 'time'])

    return db


def get_all_btc_wallets():
    db = connect_admin_db()
    return db.sql_get_from_table('btc_wallets')


def get_all_rub_wallets():
    db = connect_admin_db()
    return db.sql_get_from_table('rub_wallets')


def add_new_btc_wcreateallet(address):
    db = connect_admin_db()
    db.sql_insert_into_table('btc_wallets', [address, datetime.datetime.now()])
    return db.sql_get_from_table('btc_wallets')


def del_btc_wallet(address):
    db = connect_admin_db()
    db.sql_del_from_table('btc_wallets', ['address', f'{address}'])
    return db.sql_get_from_table('btc_wallets')


def add_new_rub_wallet(address):
    db = connect_admin_db()
    db.sql_insert_into_table('rub_wallets', [address, datetime.datetime.now()])
    return db.sql_get_from_table('rub_wallets')


def del_rub_wallet(card_number):
    db = connect_admin_db()
    db.sql_del_from_table('rub_wallets', ['card_number', f'{card_number}'])
    return db.sql_get_from_table('rub_wallets')


def connect_admin_db():
    db = Database(Database_Path, Admins_Database_Name)
    return db


def admin_new(telegram_id):
    db = connect_admin_db()
    db.sql_insert_into_table('admin', [str(telegram_id), datetime.datetime.now()])
    return db.sql_get_from_table('admin')


def admin_new_owner(telegram_id):
    db = connect_admin_db()
    db.sql_insert_into_table('owner', [str(telegram_id), datetime.datetime.now()])
    return db.sql_get_from_table('owner')


def admins():
    db = connect_admin_db()
    admins = db.sql_get_from_table('admin')
    return admins


def owners():
    db = connect_admin_db()
    owners = db.sql_get_from_table('owner')
    return owners


if not os.path.exists(os.path.join(Database_Path, Admins_Database_Name)):
    New_Admin_Database()
    logger.info(f"New {Admins_Database_Name} database")
else:
    pass
    logger.info(f"Log {Admins_Database_Name} exist")
