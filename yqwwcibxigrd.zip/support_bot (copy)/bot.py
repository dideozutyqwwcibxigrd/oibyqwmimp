import logging

import aiogram
from aiogram import Bot, Dispatcher, executor, types

from aiogram.types.inline_keyboard import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from aiogram.types import InputFile

from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.contrib.middlewares.logging import LoggingMiddleware
from aiogram.dispatcher import FSMContext, filters
from aiogram.utils.callback_data import CallbackData

from config import *

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

storage = MemoryStorage()

bot = Bot(token=Telegram_Token)
dp = Dispatcher(bot, storage=storage)
# dp.middleware.setup(LoggingMiddleware())
