from admin import *

from bot import *
from config import *

import os


@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    await message.answer(WELCOME_MESSAGE)

    # user_info = message.from_user.username

    # await bot.send_message(
    #     chat_id=TELEGRAM_SUPPORT_CHAT_ID(),
    #     text=f"""В@{user_info}.
    #     """)


@dp.message_handler(filters.ChatTypeFilter('private'))
async def forward_to_chat(message: types.Message):
    await bot.send_message(
            chat_id=TELEGRAM_SUPPORT_CHAT_ID(),
            text=f'{message.from_user.id}$\n@{message.from_user.username}\nНаписал:\n\n{message.text}\n\nОтветьте на это сообщение'
    )


@dp.message_handler(filters.IsReplyFilter(True))
async def forward_to_user(message: types.Message):
    if str(message.chat.id) == f"{TELEGRAM_SUPPORT_CHAT_ID()}":
        user_id = None
        # if message.reply_to_message.forward_from:
        #     user_id = message.reply_to_message.forward_from.id
        # elif REPLY_TO_THIS_MESSAGE in message.reply_to_message.text:
        try:
            user_id = int(message.reply_to_message.text.split('$')[0])
        except ValueError:
            user_id = None
        if user_id:
            await bot.copy_message(
                    message_id=message.message_id,
                    chat_id=user_id,
                    from_chat_id=message.chat.id
            )
        else:
            await message.answer('error')


if __name__ == '__main__':
    executor.start_polling(dp)
