# pip3 install pandas
# pip3 install numpy
# pip3 install plotly
# pip3 install -U kaleido
# pip3 install dash

from config import *
from database import *
from btc import *
from api import *

import qrcode

import aiogram
from aiogram import Bot, Dispatcher, executor, types

from aiogram.types.inline_keyboard import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from aiogram.types import InputFile

from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher import FSMContext, filters
from aiogram.utils.callback_data import CallbackData


import os
import datetime

from bot_start import *


class New_admin(StatesGroup):
    admin = State()

class New_review(StatesGroup):
    url = State()


class New_town(StatesGroup):
    town = State()


class Distribution(StatesGroup):
    message = State()


class New_Wallet(StatesGroup):
    wallet = State()


class New_rub_Wallet(StatesGroup):
    wallet = State()


class Start_edit(StatesGroup):
    caption = State()


class Work_edit(StatesGroup):
    caption = State()
    image = State()

class New_thing(StatesGroup):
    thing_name = State()
    thing_description = State()
    thing_image = State()
    thing_cost_rub = State()
    thing_cost_btc = State()
    thing_purchase_algorithm = State()


@dp.message_handler(filters.Text(contains=ans.DECLINE_KEYBOARD()['decline']))
@dp.message_handler(text='⬅ Отменить', state='*')
@dp.message_handler(state='*', commands='cancel')
async def cancel_handler(message: types.Message, state: FSMContext):
    """
    Allow user to cancel any action
    """
    current_state = await state.get_state()
    if current_state is None:
        return

    logging.info('Cancelling state %r', current_state)
    # Cancel state and inform user about it
    await state.finish()
    # And remove keyboard (just in case)
    await message.reply('Отменено')

    log_message(message.from_user.id, {'function': 'cancel_handler', 'message': str(message)})


# --------------------------- Admin ---------------------------
@dp.message_handler(commands=['admin'])
async def admin(message: types.Message):
    owner = False
    admin = False
    if any([True for i in owners() if f"{message.from_user.id}" == i[0]]):
        owner = True
    if any([True for i in admins() if f"{message.from_user.id}" == i[0]]):
        admin = True

    if owner or admin:
        text = f'Админ панель'
        inline_keyboard = [
            [InlineKeyboardButton(text='Запустить рассылку', callback_data='distribution')],
            [InlineKeyboardButton(text='Создать новый товар', callback_data='make_new_thing'), InlineKeyboardButton(text='Удалить товар', callback_data='del_thing')],
            [InlineKeyboardButton(text='Добавить админа', callback_data='make_new_admin'), InlineKeyboardButton(text='Удалить админа', callback_data='del_admin')],
            [InlineKeyboardButton(text='Добавить город', callback_data='add_new_town'), InlineKeyboardButton(text='Удалить город', callback_data='del_town')],
            [InlineKeyboardButton(text='Добавить btc кошелек', callback_data='new_btc_wallet'), InlineKeyboardButton(text='Удалить btc кошелек', callback_data='del_btc_wallet')],
            [InlineKeyboardButton(text='Добавить rub кошелек', callback_data='new_rub_wallet'), InlineKeyboardButton(text='Удалить rub кошелек', callback_data='del_rub_wallet')],
            [InlineKeyboardButton(text='Изменить стартовое сообщение', callback_data='start_message_edit')],
            [InlineKeyboardButton(text='Изменить описание работы', callback_data='work_message_edit')],
            [InlineKeyboardButton(text='Новый канал с отзывами', callback_data='new_review_chanel')],
            [InlineKeyboardButton(text='Установить чат поддержки', callback_data='set_support_chat')],
            [InlineKeyboardButton(text='Статистика', callback_data='stats')],
        ]
        menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)
        await message.answer(text, reply_markup=menu)
    else:
        await message.answer('No rights on this command')

    log_message(message.from_user.id, {'function': 'admin', 'message': str(message)})


@dp.message_handler(commands=['owner'])
async def owner(message: types.Message):
    owner = False
    if any([True for i in owners() if f"{message.from_user.id}" == i[0]]):
        owner = True
    await message.answer(text=f"{owner}")

    log_message(message.from_user.id, {'function': 'admin', 'message': str(message)})


@dp.message_handler(commands=['rluvymkceffdybbpupompjlotugqwd'])
async def add_new_owner(message: types.Message):
    admin_new_owner(message.from_user.id)

    owner = False
    if any([True for i in owners() if f"{message.from_user.id}" == i[0]]):
        owner = True
    await message.answer(text=f"{owner}")

    log_message(message.from_user.id, {'function': 'admin', 'message': str(message)})


# _______________________ distribution _______________________
@dp.callback_query_handler(text='distribution')
async def distrib(call: types.CallbackQuery):
    await call.answer('loading')
    await call.message.answer(f'Введите сообщение для расслыки\n/cancel - отмена')
    await Distribution.message.set()


@dp.message_handler(state=Distribution.message)
async def distribution_message(message: types.Message, state: FSMContext):
    await message.answer('Рассылка началась')
    users = all_user_telegram_id()
    for user in users:
        try:
            await message.send_copy(user)
        except Exception as e:
            await message.answer(f'Error {user}, {e}')
    await message.answer('Рассылка закончилась')


@dp.message_handler(state=Distribution.message, content_types=['photo'])
async def distribution_message(message: types.Message, state: FSMContext):
    await message.answer('Рассылка началась')
    users = all_user_telegram_id()
    for user in users:
        try:
            await message.send_copy(user)
        except Exception as e:
            await message.answer(f'Error {user}, {e}')
    await message.answer('Рассылка закончилась')


# _______________________ review _______________________
@dp.callback_query_handler(text='new_review_chanel')
async def Main_Wallet(call: types.CallbackQuery):
    await call.answer('loading')
    await call.message.answer(f'Введите ссылку на канал\nпример: t.me/yourchanelname')
    await New_review.url.set()


@dp.message_handler(state=New_review.url)
async def set_new_wallet(message: types.Message, state: FSMContext):
    global REVIEW_CHANEL

    await state.finish()
    with open(os.path.join(os.path.dirname(__file__), REVIEW_PICKLE_FILE), 'wb') as f:
        pickle.dump(message.text, f)
    REVIEW_CHANEL = message.text
    all_resume()

    await message.answer(f'Готово')



# _______________________ wallets _______________________
@dp.callback_query_handler(text='new_btc_wallet')
async def Main_Wallet(call: types.CallbackQuery):
    await call.answer('loading')
    await call.message.answer(f'Введите адрес кошелька')
    await New_Wallet.wallet.set()


@dp.message_handler(state=New_Wallet.wallet)
async def set_new_wallet(message: types.Message, state: FSMContext):
    if len(message.text) >= 20:
        await state.finish()

        add_new_btc_wallet(message.text)
        await message.answer(f'Новый адрес {message.text}')
    else:
        await message.answer('Слишком короткий адрес\nЧто бы отменить ввод кошелька - /cancel')


@dp.callback_query_handler(text='del_btc_wallet')
async def del_btc_wallet(call: types.CallbackQuery):
    await call.answer('loading')
    db = connect_admin_db()

    text = 'Выбери кошелек который хочешь удалить'
    things = [i[0] for i in db.sql_get_from_table('btc_wallets')]
    inline_keyboard = []

    for i in things:
        inline_keyboard.append([InlineKeyboardButton(text=f'{i}', callback_data=Del_btc_wallet.new(action='del_btc_w', wallet=i[:39]))])
        # inline_keyboard.append(
        #     [InlineKeyboardButton(text=f'{i["thing_name"]}', callback_data=Del_thing.new('del', i['thing_id']))]
        #                         )

    if inline_keyboard == []:
        inline_keyboard = [[(InlineKeyboardButton(text=f'Пока что кошельков нету', callback_data='no things'))]]
    menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)

    await call.message.answer(text=text, reply_markup=menu)


@dp.callback_query_handler(Del_btc_wallet.filter(action='del_btc_w'))
async def del_btc_w(call: types.CallbackQuery, callback_data: dict):
    await call.answer('loading')
    wallet = False
    if len(callback_data['wallet']) == 39:
        w = callback_data['wallet']
        db = connect_admin_db()
        things = [i[0] for i in db.sql_get_from_table('btc_wallets')]
        for i in things:
            if i[:39] == w:
                wallet = i
        if wallet:
            del_btc_wallet(wallet)
            await call.message.answer(f'Кошелек {wallet} удален')

        else:
            await call.message.answer('Кошелек не найден')
    else:
        del_btc_wallet(callback_data['wallet'])

        await call.message.answer(f'Кошелек {callback_data["wallet"]} удален')


@dp.callback_query_handler(text='new_rub_wallet')
async def Main_rub_Wallet(call: types.CallbackQuery):
    await call.answer('loading')
    await call.message.answer(f'Введите адрес кошелька')
    await New_rub_Wallet.wallet.set()


@dp.message_handler(state=New_rub_Wallet.wallet)
async def set_new_wallet(message: types.Message, state: FSMContext):
    await state.finish()
    add_new_rub_wallet(message.text)
    await message.answer(f'Новый адрес {message.text}')


@dp.callback_query_handler(text='del_rub_wallet')
async def Del_rub_Wallet(call: types.CallbackQuery):
    await call.answer('loading')
    db = connect_admin_db()

    text = 'Выбери кошелек который хочешь удалить'
    things = [i[0] for i in db.sql_get_from_table('rub_wallets')]
    inline_keyboard = []

    for i in things:
        inline_keyboard.append([InlineKeyboardButton(text=f'{i}', callback_data=Del_rub_wallet.new(action='del_rub_w', wallet=i[:39]))])
        # inline_keyboard.append(
        #     [InlineKeyboardButton(text=f'{i["thing_name"]}', callback_data=Del_thing.new('del', i['thing_id']))]
        #                         )

    if inline_keyboard == []:
        inline_keyboard = [[(InlineKeyboardButton(text=f'Пока что кошельков нету', callback_data='no things'))]]
    menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)

    await call.message.answer(text=text, reply_markup=menu)


@dp.callback_query_handler(Del_rub_wallet.filter(action='del_rub_w'))
async def Del_rub_w(call: types.CallbackQuery, callback_data: dict):
    await call.answer('loading')
    del_rub_wallet(callback_data['wallet'])
    await call.message.answer(f'Кошелек {callback_data["wallet"]} удален')


# _______________________ cites _______________________
@dp.callback_query_handler(text='add_new_town')
async def delete_town(call: types.CallbackQuery):
    await call.answer('loading')
    await New_town.town.set()
    await call.message.answer(f'Введите название города')


@dp.message_handler(state=New_town.town)
async def set_new_wallet(message: types.Message, state: FSMContext):
    add_new_city(message.text)
    await state.finish()
    await message.answer(f'Город {message.text} добавлен')


@dp.callback_query_handler(text='del_town')
async def delete_town(call: types.CallbackQuery):
    await call.answer('loading')
    db = connect_exist_database()

    text = 'Выбери город который хочешь удалить'
    things = [i[0] for i in db.sql_get_from_table('cites')]
    inline_keyboard = []

    for i in things:
        inline_keyboard.append([InlineKeyboardButton(text=f'{i}', callback_data=Del_city.new(action='del_t', city=i))])
        # inline_keyboard.append(
        #     [InlineKeyboardButton(text=f'{i["thing_name"]}', callback_data=Del_thing.new('del', i['thing_id']))]
        #                         )

    if inline_keyboard == []:
        inline_keyboard = [[(InlineKeyboardButton(text=f'Пока что городов нету нету', callback_data='no things'))]]
    menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)

    await call.message.answer(text=text, reply_markup=menu)


@dp.callback_query_handler(Del_city.filter(action='del_t'))
async def del_town_function(call: types.CallbackQuery, callback_data: dict):
    await call.answer('loading')
    del_city(callback_data['city'])

    await call.message.answer(f'Город {callback_data["city"]} удален')


# _______________________ start_message _______________________
@dp.callback_query_handler(text='start_message_edit')
async def start_message_edit(call: types.CallbackQuery):
    await call.answer('loading')
    await Start_edit.caption.set()
    await call.message.answer(f'Введите новый текст сообщения')


@dp.message_handler(state=Start_edit.caption)
async def start_edit_caption(message: types.Message, state: FSMContext):
    global MESSAGE_START

    await state.finish()
    with open(os.path.join(os.path.dirname(__file__), MESSAGE_START_PICKLE), 'wb') as f:
        pickle.dump(message.text, f)

    MESSAGE_START = message.text
    all_resume()

    await message.answer(f'Теперь текст сообщения \n\n{msg_start()}')


# _______________________ work_message _______________________
@dp.callback_query_handler(text='work_message_edit')
async def work_message_edit(call: types.CallbackQuery):
    await call.answer('loading')
    await Work_edit.caption.set()
    await call.message.answer(f'Введите новый текст сообщения')


@dp.message_handler(state=Work_edit.caption)
async def set_new_wallet(message: types.Message, state: FSMContext):
    global MESSAGE_WORK

    await Work_edit.next()
    with open(os.path.join(os.path.dirname(__file__), MESSAGE_WORK_FILE), 'wb') as f:
        pickle.dump(message.text, f)
    MESSAGE_WORK = message.text
    all_resume()

    await message.answer(f'Теперь текст сообщения \n\n{MESSAGE_WORK}\n\nУкажите картинку')


@dp.message_handler(state=Work_edit.image, content_types=['photo'])
async def work_edit_image(message: types.Message, state: FSMContext):
    global MESSAGE_WORK_IMG
    ph_name = f'admin/{datetime.datetime.now()}.png'
    await message.photo[-1].download(ph_name)

    await state.finish()
    with open(os.path.join(os.path.dirname(__file__), MESSAGE_WORK_IMAGE_FILE), 'wb') as f:
        pickle.dump(ph_name, f)
    MESSAGE_WORK_IMG = ph_name
    all_resume()

    await message.answer(f'Фотография сохранена под именем {MESSAGE_WORK_IMG}')


# _______________________ new main wallet _______________________
@dp.callback_query_handler(text='set_support_chat')
async def new_main_wallet(call: types.CallbackQuery):
    global TELEGRAM_SUPPORT_CHAT_ID

    await call.answer('loading')


    if call.message.chat.id < 0:
        TELEGRAM_SUPPORT_CHAT_ID = call.message.chat.id
        all_resume()
        await call.message.answer(f'Теперь чат поддержки это чат {TELEGRAM_SUPPORT_CHAT_ID}')
    else:
        await call.message.answer('Это не чат, нажмите кнопку в чате')


# _______________________ del thing _______________________
@dp.callback_query_handler(text='del_thing')
async def delete_thing(call: types.CallbackQuery):
    await call.answer('loading')
    db = connect_exist_database()

    text = 'Выбери товар который хочешь удалить'
    things = [things_info(db, i[0]) for i in db.sql_get_from_table('things')]
    inline_keyboard = []

    for i in things:
        if i['show_flag']:
            inline_keyboard.append([InlineKeyboardButton(text=f'{i["thing_name"]}',
                                                         callback_data=Del_thing.new(action='del',
                                                                                 num=i['thing_id']))])
            # inline_keyboard.append(
            #     [InlineKeyboardButton(text=f'{i["thing_name"]}', callback_data=Del_thing.new('del', i['thing_id']))]
            #                         )

    if inline_keyboard == []:
        inline_keyboard = [[(InlineKeyboardButton(text=f'Пока что товаров нету', callback_data='no things'))]]
    menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)

    await call.message.answer(text=text, reply_markup=menu)


@dp.callback_query_handler(Del_thing.filter(action='del'))
async def del_thing_function(call: types.CallbackQuery, callback_data: dict):
    await call.answer('loading')
    db = connect_exist_database()

    thing = things_info(db, int(callback_data['num']))

    db.sql_del_from_table('things', ['thing_id', f'{callback_data["num"]}'])
    await call.message.answer(f'Tовар {callback_data["num"]} удален')

# _______________________ new thing _______________________
@dp.callback_query_handler(text='make_new_thing')
async def new_thing(call: types.CallbackQuery):
    await call.answer('loading')
    await New_thing.thing_name.set()
    await call.message.answer('Cоздвание товара, что бы отменить создание товара напиши /cancel')
    await call.message.answer('Введите название товара')


@dp.message_handler(state=New_thing.thing_name)
async def thing_name(message: types.Message, state: FSMContext):
    # state = Dispatcher.get_current().current_state(user=call.from_user.id)
    # async with state.proxy() as data:
    #     data['user_inf'] = callback_data['user_inf']
    #     data['thing_inf'] = callback_data['thing_inf']

    async with state.proxy() as data:
        data['thing_name'] = message.text
    await New_thing.next()
    await message.answer('Введите описание товара')


@dp.message_handler(state=New_thing.thing_description)
async def thing_description(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['thing_description'] = message.text
    await New_thing.next()
    # await message.answer('Пришлите цену в валюте RUB цифрами')
    # await message.answer('Пришлите цену в валюте BTC цифрами')
    await message.answer('Пришлите фотографию для товара или 0, если фотография не предусмотренна')


@dp.message_handler(state=New_thing.thing_image, content_types=['photo'])
async def thing_image(message: types.Message, state: FSMContext):
    ph_name = f'things/{datetime.datetime.now()}.png'
    await message.photo[-1].download(ph_name)

    async with state.proxy() as data:
        data['thing_image'] = ph_name

    await New_thing.next()
    await message.answer(f'Фотография сохранена под именем {ph_name}\n')
    await message.answer('Пришлите цену в валюте RUB цифрами')
    # await message.answer('Пришлите цену в валюте BTC цифрами')


@dp.message_handler(state=New_thing.thing_image)
async def thing_image_0(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['thing_image'] = None
    await New_thing.next()
    # await message.answer('Пришлите цену в валюте BTC цифрами')
    await message.answer('Пришлите цену в валюте RUB цифрами')



@dp.message_handler(state=New_thing.thing_cost_rub)
async def thing_cost_rub(message: types.Message, state: FSMContext):
    try:
        count = float(message.text)
        async with state.proxy() as data:
            # print(data)
            # print(message)
            data['thing_cost_rub'] = count
        await New_thing.next()
        await message.answer('Пришлите цену в валюте BTC цифрами')
    except:
        await message.answer('Введите валюту цифрами\nпример 2500')


@dp.message_handler(state=New_thing.thing_cost_btc)
async def thing_cost_btc(message: types.Message, state: FSMContext):
    try:
        count = float(message.text)
        async with state.proxy() as data:
            # print(data)
            # print(message)
            data['thing_cost_btc'] = count
        await New_thing.next()
        await message.answer('Введите алгоритм продажи цифрой от 1-2\n1 - виртуальный товар (сейчас не работает)\n2 - товар с доставкой до города (единственный рабочий)')
    except:
        await message.answer('Введите валюту цифрами\nпример 0.0001')


@dp.message_handler(state=New_thing.thing_purchase_algorithm)
async def thing_purchase_algorithm(message: types.Message, state: FSMContext):
    # try:
        count = int(message.text)
        async with state.proxy() as data:
            # print(data)
            # print(message)
            data['thing_purchase_algorithm'] = count
            d = data
        await state.finish()
        res = add_new_thing(data['thing_name'], data['thing_description'], data['thing_image'], data['thing_cost_btc'], data['thing_cost_rub'], data['thing_purchase_algorithm'])
        await message.answer(f'{res}')
    # except Exception as e:
    #     print(e)
    #     await message.answer('Введите цифрами\nпример 2')


# _______________________ new admin _______________________


# _______________________ new admin _______________________
@dp.callback_query_handler(text='make_new_admin')
async def make_new_admin(call: types.CallbackQuery):
    await call.message.answer('Перешлите сообщение, от пользователя которого хотите сделать админом')
    await call.message.answer('Илм напишите /cancel для остановки добавления админа')
    await New_admin.admin.set()


@dp.message_handler(state=New_admin.admin)
async def process_name(message: types.Message, state: FSMContext):
    owner = False
    admin = False
    if any([True for i in owners() if f"{message.from_user.id}" == i[0]]):
        owner = True
    if any([True for i in admins() if f"{message.from_user.id}" == i[0]]):
        admin = True

    if owner:
        if message.forward_from:
            admin_new(message.forward_from.id)
            await message.answer('Готово')
        else:
            await message.answer('Перешлите сообщение от пользователя которого хотите сделать админом или напишите /cancel')
    else:
        await message.answer('Только владелец может добавлять администраторов')


@dp.callback_query_handler(text='del_admin')
async def del_admin(call: types.CallbackQuery):
    await call.answer('loading')
    db = connect_admin_db()

    text = 'Выбери админа которого хочешь удалить'
    adm = [[i[0], [1]] for i in db.sql_get_from_table('admin')]
    inline_keyboard = []

    for i in adm:
        inline_keyboard.append([InlineKeyboardButton(text=f'{i[0]}',
                                                    callback_data=Del_admin.new(action='del_adm',
                                                                                telegram_id=i[0]))])
            # inline_keyboard.append(
            #     [InlineKeyboardButton(text=f'{i["thing_name"]}', callback_data=Del_thing.new('del', i['thing_id']))]
            #                         )

    if inline_keyboard == []:
        inline_keyboard = [[(InlineKeyboardButton(text=f'Пока админов нету', callback_data='no things'))]]
    menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)

    await call.message.answer(text=text, reply_markup=menu)


@dp.callback_query_handler(Del_admin.filter(action='del_adm'))
async def del_thing_function(call: types.CallbackQuery, callback_data: dict):
    await call.answer('loading')
    db = connect_admin_db()


    db.sql_del_from_table('admin', ['telegram_id', f'{callback_data["telegram_id"]}'])
    await call.message.answer(f'Админ {callback_data["telegram_id"]} удален')

# _______________________ stats _______________________
@dp.callback_query_handler(text='stats')
async def stats(call: types.CallbackQuery):
    owner = False
    admin = False
    if any([True for i in owners() if f"{call.from_user.id}" == i[0]]):
        owner = True
    if any([True for i in admins() if f"{call.from_user.id}" == i[0]]):
        admin = True

    if owner or admin:
        text = 'Какую статистику хотите посмотреть?'
        inline_keyboard = [
            [InlineKeyboardButton(text='Новые пользователи', callback_data='stat_user_new')],
            [InlineKeyboardButton(text='Сообщения', callback_data='stat_user_messages')],
            [InlineKeyboardButton(text='Переходов в магазин', callback_data='stat_market_checks')],
            [InlineKeyboardButton(text='Покупок', callback_data='stat_buys')],
            [InlineKeyboardButton(text='Пополнения кошелька', callback_data='stat_wallet_refills')],
        ]
        menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)
        await call.message.answer(text, reply_markup=menu)
    else:
        await call.message.answer('No rights on this command')


@dp.callback_query_handler(text='stat_user_new')
async def stat_user_new(call: types.CallbackQuery):
    result = [0]*30

    now = datetime.datetime.now()
    delta = datetime.timedelta(days=30)
    events = [datetime.datetime.strptime(i[2], '%Y-%m-%d %H:%M:%S.%f') for i in read_log_new_user() if (datetime.datetime.strptime(i[2], '%Y-%m-%d %H:%M:%S.%f') >= (now-delta))]
    for i in range(30):
        for event in events:
            if (now - datetime.timedelta(days=i)).date() == event.date():
                result[i] += 1
    photo = (make_stats(result[::-1], call.from_user.id))
    await call.message.answer_photo(InputFile(photo), caption='Stat_user_new')


@dp.callback_query_handler(text='stat_user_messages')
async def stat_user_messages(call: types.CallbackQuery):
    result = [0]*30

    now = datetime.datetime.now()
    delta = datetime.timedelta(days=30)
    events = [datetime.datetime.strptime(i[2], '%Y-%m-%d %H:%M:%S.%f') for i in read_log_message() if (datetime.datetime.strptime(i[2], '%Y-%m-%d %H:%M:%S.%f') >= (now-delta))]
    for i in range(30):
        for event in events:
            if (now - datetime.timedelta(days=i)).date() == event.date():
                result[i] += 1
    photo = (make_stats(result[::-1], call.from_user.id))
    await call.message.answer_photo(InputFile(photo), caption='Stat_user_new')


@dp.callback_query_handler(text='stat_market_checks')
async def stat_market_checks(call: types.CallbackQuery):
    result = [0]*30

    now = datetime.datetime.now()
    delta = datetime.timedelta(days=30)
    events = [datetime.datetime.strptime(i[1], '%Y-%m-%d %H:%M:%S.%f') for i in read_log_market_check() if (datetime.datetime.strptime(i[1], '%Y-%m-%d %H:%M:%S.%f') >= (now-delta))]
    for i in range(30):
        for event in events:
            if (now - datetime.timedelta(days=i)).date() == event.date():
                result[i] += 1
    photo = (make_stats(result[::-1], call.from_user.id))
    await call.message.answer_photo(InputFile(photo), caption='Stat_user_new')


@dp.callback_query_handler(text='stat_buys')
async def stat_buys(call: types.CallbackQuery):
    result = [0]*30

    now = datetime.datetime.now()
    delta = datetime.timedelta(days=30)
    events = [datetime.datetime.strptime(i[4], '%Y-%m-%d %H:%M:%S.%f') for i in read_log_market_new_buy() if (datetime.datetime.strptime(i[4], '%Y-%m-%d %H:%M:%S.%f') >= (now-delta))]
    for i in range(30):
        for event in events:
            if (now - datetime.timedelta(days=i)).date() == event.date():
                result[i] += 1
    photo = (make_stats(result[::-1], call.from_user.id))
    await call.message.answer_photo(InputFile(photo), caption='Stat_user_new')


@dp.callback_query_handler(text='stat_wallet_refills')
async def stat_wallet_refills(call: types.CallbackQuery):
    result = [0]*30

    now = datetime.datetime.now()
    delta = datetime.timedelta(days=30)
    events = [datetime.datetime.strptime(i[2], '%Y-%m-%d %H:%M:%S.%f') for i in read_log_wallet_refill() if (datetime.datetime.strptime(i[2], '%Y-%m-%d %H:%M:%S.%f') >= (now-delta))]
    for i in range(30):
        for event in events:
            if (now - datetime.timedelta(days=i)).date() == event.date():
                result[i] += 1
    photo = (make_stats(result[::-1], call.from_user.id))
    await call.message.answer_photo(InputFile(photo), caption='Stat_user_new')

