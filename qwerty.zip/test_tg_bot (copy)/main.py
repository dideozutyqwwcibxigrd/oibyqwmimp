import random

from config import *
from database import *
from btc import *

import qrcode

import aiogram
from aiogram import Bot, Dispatcher, executor, types

from aiogram.types.inline_keyboard import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from aiogram.types import InputFile

from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher import FSMContext, filters
from aiogram.utils.callback_data import CallbackData
from aiogram.utils.executor import start_webhook


from bot_start import *
from admin import *


class Support_Message(StatesGroup):
    from_user = State()
    message = State()


class Purchase_Algorithm_2(StatesGroup):
    user_inf = State()
    thing_inf = State()
    City = State()


async def main_keyboard(message: types.Message):
    keyboard_text, keyboard_image, reply_markup = ans.keyboard()
    await message.answer_animation(InputFile(keyboard_image), caption=' ', reply_markup=reply_markup)


async def decline_keyboard(message: types.Message):
    keyboard_text, menu = ans.decline_support()
    await message.answer(text=keyboard_text, reply_markup=menu)


@dp.message_handler(filters.Text(contains=ans.DECLINE_KEYBOARD()['decline']))
@dp.message_handler(text='⬅ Отменить', state='*')
@dp.message_handler(state='*', commands='cancel')
async def cancel_handler(message: types.Message, state: FSMContext):
    """
    Allow user to cancel any action
    """
    current_state = await state.get_state()
    if current_state is None:
        return

    logging.info('Cancelling state %r', current_state)
    # Cancel state and inform user about it
    await state.finish()
    # And remove keyboard (just in case)
    await message.reply('Отменено', reply_markup=types.ReplyKeyboardRemove())
    await main_keyboard(message)

    log_message(message.from_user.id, {'function': 'cancel_handler', 'message': str(message)})


@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    db = connect_exist_database()

    new_user_log = create_user(db, message.from_user.id, message.from_user.first_name, message.from_user.last_name)

    message_text = ans.start()

    await message.answer(message_text)
    await main_keyboard(message)

    log_message(message.from_user.id, {'function': 'start', 'message': str(message)})
    if not new_user_log['user_already_exist']:
        log_new_user(new_user_log['telegram_id'], new_user_log)



# profile
@dp.message_handler(commands=['profile'])
@dp.message_handler(filters.Text(contains=ans.MAIN_KEYBOARD()['profile']))
async def profile(message: types.Message):
    db = connect_exist_database()
    info = user_all_info(db, message.from_user.id)

    message_text, reply_markup = ans.profile_message(info)
    await message.answer(message_text, reply_markup=reply_markup)

    log_message(message.from_user.id, {'function': 'profile', 'message': str(message)})



@dp.callback_query_handler(text='transactions')
async def transactions(update: types.update):
    db = connect_exist_database()
    info = user_all_info(db, update.from_user.id)

    text, menu = ans.rub_transactions(info)
    await bot.edit_message_text(chat_id=update.message.chat.id, message_id=update.message.message_id,
                                text=text, reply_markup=menu,)

    log_message(update.message.from_user.id, {'function': 'transactions', 'message': str(update.message)})



@dp.callback_query_handler(text='btc_transactions')
async def btc_transactions(update: types.update):
    db = connect_exist_database()
    info = user_all_info(db, update.from_user.id)

    text, menu = ans.btc_transactions(info)
    await bot.edit_message_text(chat_id=update.message.chat.id, message_id=update.message.message_id,
                                text=text, reply_markup=menu,)

    log_message(update.message.from_user.id, {'function': 'btc_transactions', 'message': str(update.message)})



@dp.callback_query_handler(text='rub_add_balance')
async def rub_add_balance(call: types.CallbackQuery):
    db = connect_exist_database()
    info = user_all_info(db, call.from_user.id)


    # refill_wallet(db, info['wallet_id'], 100)
    # info = user_all_info(db, update.from_user.id)
    #
    # text, menu = ans.rub_transactions(info)
    # await bot.edit_message_text(chat_id=update.message.chat.id, message_id=update.message.message_id,
    #                             text=text, reply_markup=menu,)
    await call.answer('Пополнение рублей пока что не доступно')

    log_message(call.message.from_user.id, {'function': 'rub_add_balance', 'message': str(call.message)})



# @dp.callback_query_handler(text='btc_add_balance')
# async def btc_add_balance(call: types.CallbackQuery):
#     db = connect_exist_database()
#     info = user_all_info(db, call.from_user.id)
#
#     # refill_wallet(db, info['wallet_id'], 100)
#     # info = user_all_info(db, update.from_user.id)
#
#     text, img, reply_markup = ans.btc_add_balance(info)
#     await call.answer('loading')
#     await call.message.answer_photo(InputFile(img), caption=text, reply_markup=reply_markup)
#
#     # await bot.edit_message_text(chat_id=update.message.chat.id, message_id=update.message.message_id,
#     #                             text=text, reply_markup=menu,)
#     log_message(call.message.from_user.id, {'function': 'btc_add_balance', 'message': str(call.message)})



@dp.callback_query_handler(text='btc_update_balance')
async def btc_update_balance(call: types.CallbackQuery):
    db = connect_exist_database()
    info = user_all_info(db, call.from_user.id, real_wallet_inf=True)

    await call.answer('loading')

    if info['btc_balance'] != info['btc_real_balance'] and (info['btc_balance'] or info['btc_balance']==0) and info['btc_real_balance']:
        delta = info['btc_real_balance'] - info['btc_balance']
        refill_btc_wallet(db, info['wallet_id'], delta, info['btc_address'], info['btc_wif'])

        info = user_all_info(db, call.from_user.id)
        text, menu = ans.btc_transactions(info)

        await call.message.answer(f'Баланс пополнен на {delta}')
        await call.message.answer(text)
    else:
        # print(info['btc_real_balance'], info['btc_balance'], info['btc_real_balance'] != info['btc_balance'])
        await call.message.answer(f'Баланс кошелька не изменился')

    # db = connect_exist_database()
    # info = user_all_info(db, update.from_user.id)
    #
    # refill_wallet(db, info['wallet_id'], 100)
    # info = user_all_info(db, update.from_user.id)
    #
    # text, menu = ans.rub_transactions(info)
    # await bot.edit_message_text(chat_id=update.message.chat.id, message_id=update.message.message_id,
    #                             text=text, reply_markup=menu,)

    log_message(call.message.from_user.id, {'function': 'btc_update_balance', 'message': str(call.message)})



@dp.callback_query_handler(text='things_basket')
async def things_basket(call: types.CallbackQuery):
    db = connect_exist_database()
    info = user_all_info(db, call.from_user.id)

    message_text, message_menu = ans.things_basket(info)
    await bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id,
                                text=message_text, reply_markup=message_menu)

    log_message(call.message.from_user.id, {'function': 'things_basket', 'message': str(call.message)})



@dp.callback_query_handler(Thing.filter(action='purchased_thing'))
async def thing_function(call: types.CallbackQuery, callback_data: dict):
    db = connect_exist_database()
    thing = things_info(db, int(callback_data['num']))

    text, image = ans.thing_message(thing)
    if image:
        await call.message.answer_photo(InputFile(image), caption=text)
    else:
        await call.message.answer(text=text)

    log_message(call.message.from_user.id, {'function': 'thing_function', 'message': str(call.message)})



# @dp.message_handler(commands=['balance'])
# @dp.message_handler(filters.Text(contains=ans.MAIN_KEYBOARD()['balance']))
# async def balance(message: types.Message):
#     db = connect_exist_database()
#     info = user_all_info(db, message.from_user.id)
#
#     text, menu = ans.balance(info)
#     await message.answer(text=text, reply_markup=menu,)
#
#     log_message(message.from_user.id, {'function': 'balance', 'message': str(message)})


# market
@dp.message_handler(commands=['market'])
@dp.message_handler(filters.Text(contains=ans.MAIN_KEYBOARD()['market']))
async def market(message: types.Message):
    db = connect_exist_database()
    # info = all_user_info(db, message.from_user.id, message.from_user.first_name, message.from_user.last_name)
    text, reply_markup = ans.market(db, db.sql_get_from_table('things'))

    await message.answer(text=text, reply_markup=reply_markup)

    log_message(message.from_user.id, {'function': 'market', 'message': str(message)})
    log_market_check(message.from_user.id)


@dp.callback_query_handler(Thing.filter(action='buy_thing'))
async def thing_function(call: types.CallbackQuery, callback_data: dict):
    db = connect_exist_database()

    thing = things_info(db, int(callback_data['num']))
    text, menu, image = ans.buy_thing_message(thing)

    if image:
        await call.message.answer_photo(InputFile(image), caption=text, reply_markup=menu)
    else:
        await call.message.answer(text=text,
                                    reply_markup=menu)

    log_message(call.message.from_user.id, {'function': 'thing_function', 'message': str(call.message)})
    log_market_thing_check(call.message.from_user.id, thing['thing_id'])


@dp.callback_query_handler(Thing.filter(action='buy'))
async def buy_thing_function(call: types.CallbackQuery, callback_data: dict):
    db = connect_exist_database()
    thing = things_info(db, int(callback_data['num']))
    info = user_all_info(db, call.from_user.id)

    if thing['purchase_algorithm'] == '1':
        text, menu = ans.buy_thing_purchase_algorithm_1(info, thing)
        await bot.edit_message_caption(
            chat_id = call.message.chat.id, message_id = call.message.message_id,
            caption= text, reply_markup = menu,
        )
    elif thing['purchase_algorithm'] == '2':
        text, menu = ans.buy_thing_purchase_algorithm_2(info, thing)
        try:
            await bot.edit_message_caption(
                chat_id=call.message.chat.id, message_id=call.message.message_id,
                caption=text, reply_markup=menu,
            )
        except:
            await bot.edit_message_text(
                chat_id=call.message.chat.id, message_id=call.message.message_id,
                text=text, reply_markup=menu,
            )

    log_message(call.message.from_user.id, {'function': 'buy_thing_function', 'message': str(call.message)})



@dp.callback_query_handler(Buy_thing_purchase_algorithm_1.filter())
async def Buy_thing_purchase_algorithm_1(call: types.CallbackQuery, callback_data: dict):
    print(callback_data)

    log_message(call.message.from_user.id, {'function': 'Buy_thing_purchase_algorithm_1', 'message': str(call.message)})



@dp.callback_query_handler(Choose_City.filter())
async def Buy_thing_purchase_algorithm_2_Choose_City(call: types.CallbackQuery, callback_data: dict):
    city = False
    if callback_data['city'] != 'other':
        city = callback_data['city']

    db = connect_exist_database()
    thing = things_info(db, int(callback_data['thing_inf']))
    info = user_all_info(db, int(callback_data['user_inf']))

    if not city:

        await Purchase_Algorithm_2.City.set()

        state = Dispatcher.get_current().current_state(user=call.from_user.id)
        async with state.proxy() as data:
            data['user_inf'] = callback_data['user_inf']
            data['thing_inf'] = callback_data['thing_inf']

        text, menu = ans.buy_thing_purchase_algorithm_2_city_other()

        await call.message.answer(text=text, reply_markup=menu)
    else:
        # await Purchase_Algorithm_2.Other.set()
        state = Dispatcher.get_current().current_state(user=call.from_user.id)
        async with state.proxy() as data:
            data['city'] = city

        reply_text, reply_keyboard = ans.buy_thing_purchase_algorithm_2_city()
        inline_text, inline_keyboard = ans.buy_thing(info, thing, other=city)

        await state.finish()
        await call.message.answer(text=reply_text, reply_markup=reply_keyboard)
        await call.message.answer(text=inline_text, reply_markup=inline_keyboard)

    log_message(call.message.from_user.id, {'function': 'Buy_thing_purchase_algorithm_2_Choose_City', 'message': str(call.message)})



@dp.message_handler(state=Purchase_Algorithm_2.City)
async def Buy_thing_purchase_algorithm_2_city(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['City'] = message.text

    await Purchase_Algorithm_2.next()

    async with state.proxy() as data:
        db = connect_exist_database()
        thing = things_info(db, int(data['thing_inf']))
        info = user_all_info(db, int(data['user_inf']))
        # info = data['user_inf']
        # thing = data['thing_inf']
        city = data['City']

    # text = 'Укажите адрес доставки'
    # keyboard = [
    #     [KeyboardButton(text=DECLINE_KEYBOARD['decline'])]
    # ]
    #
    # menu = ReplyKeyboardMarkup(keyboard=keyboard, resize_keyboard=True)
    #
    # await message.answer(text, reply_markup=menu)

    reply_text, reply_keyboard = ans.buy_thing_purchase_algorithm_2_city()
    inline_text, inline_keyboard = ans.buy_thing(info, thing, other=city)

    await state.finish()
    await message.answer(text=reply_text, reply_markup=reply_keyboard)
    await message.answer(text=inline_text, reply_markup=inline_keyboard)

    log_message(message.from_user.id, {'function': 'Buy_thing_purchase_algorithm_2_city', 'message': str(message)})


@dp.callback_query_handler(Buy_thing.filter(currency='rub'))
async def rub_buy(call: types.CallbackQuery, callback_data: dict):
    await call.answer('вам напишет оператор')

    # await call.answer('Использование рублей в качестве оплаты пока что не доступно')

    db = connect_exist_database()
    thing = things_info(db, int(callback_data['thing_inf']))
    info = user_all_info(db, int(callback_data['user_inf']))

    await call.answer('loading')
    if get_all_rub_wallets() == []:
        await call.message.answer('Не добавлены способы оплаты в этой валюте')
    else:
        wallet = random.choice(get_all_rub_wallets())[0]

        text = f'Оплата товара\nПеревидите {thing["cost"]["rub"]} рублей на карту\n{wallet}\n\nНажмите кнопку только после оплаты'
        keyboard = [
            [InlineKeyboardButton(text='Оплатил', callback_data=BUY.new(currency='rub', wallet=wallet[:12],
                                                                            user_inf=info['telegram_id'], thing_inf=thing['thing_id'], other=callback_data['other']))],
        ]
        inline_menu = InlineKeyboardMarkup(inline_keyboard=keyboard)

        await call.message.answer(text=text, reply_markup=inline_menu)

    log_message(call.message.from_user.id, {'function': 'rub_buy', 'message': str(call.message)})
    # log_market_new_buy(call.from_user.id, thing, price)


@dp.callback_query_handler(Buy_thing.filter(currency='btc'))
async def btc_buy(call: types.CallbackQuery, callback_data: dict):
    await call.answer('вам напишет оператор')

    db = connect_exist_database()
    thing = things_info(db, int(callback_data['thing_inf']))
    info = user_all_info(db, int(callback_data['user_inf']))

    await call.answer('loading')
    if get_all_btc_wallets() == []:
        await call.message.answer('Не добавлены способы оплаты в этой валюте')
    else:
        wallet = random.choice(get_all_btc_wallets())[0]

        text = f'Оплата товара\nПеревидите {thing["cost"]["btc"]} биткоинов на кошелек\n{wallet}\n\nНажмите кнопку только после оплаты'
        keyboard = [
            [InlineKeyboardButton(text='Оплатил', callback_data=BUY.new(currency='btc', wallet=wallet[:12],
                                                                            user_inf=info['telegram_id'], thing_inf=thing['thing_id'], other=callback_data['other']))],
        ]
        inline_menu = InlineKeyboardMarkup(inline_keyboard=keyboard)

        await call.message.answer(text=text, reply_markup=inline_menu)


@dp.callback_query_handler(BUY.filter())
async def final_BUY(call: types.CallbackQuery, callback_data: dict):
    db = connect_exist_database()
    thing = things_info(db, int(callback_data['thing_inf']))
    info = user_all_info(db, int(callback_data['user_inf']))

    text = f"@{call.from_user.username}\n{call.from_user.first_name} {call.from_user.last_name}\nОплатил на {callback_data['currency']} адрес: {callback_data['wallet']}...\n\nТовар: {thing['thing_name']}\n{thing['description']}\n\nЦена {thing['cost'][callback_data['currency']]}"
    await bot.send_message(
        chat_id=TELEGRAM_SUPPORT_CHAT_ID,
        # reply_to_message_id=forwarded.message_id,
        text=text
    )
    await call.message.answer(text="Вам напишет оператор со всей нужной информацией")
# buy_thing_purchase_algorithm_1_rub Buy_thing


# --------------------------- Review ---------------------------
@dp.message_handler(commands=['review'])
@dp.message_handler(filters.Text(contains=ans.MAIN_KEYBOARD()['review']))
async def support(message: types.Message):
    message_text, message_menu = ans.review()
    await message.answer(text=message_text,
                         reply_markup=message_menu)

    log_message(message.from_user.id, {'function': 'review', 'message': str(message)})


# ---------------------------Support---------------------------
@dp.message_handler(commands=['support'])
@dp.message_handler(filters.Text(contains=ans.MAIN_KEYBOARD()['support']))
async def support(message: types.Message):
    message_text, message_menu = ans.support()
    await message.answer(text=message_text,
                         reply_markup=message_menu)

    log_message(message.from_user.id, {'function': 'support', 'message': str(message)})



@dp.callback_query_handler(text='write to support')
async def write_to_support(call: types.CallbackQuery):
    await decline_keyboard(call.message)

    await Support_Message.from_user.set()

    # await update.message.answer("Написать в поддержку\n Здесь вы можете написать сообщение создателям бота, задать свой вопрос, предложить идею или сообщить об ошибке.")

    # await bot.edit_message_text(chat_id=update.message.chat.id, message_id=update.message.message_id,
    #                             text='Спасибо что обратились в поддержку, ваше следующее сообшение будет сохранено и отправлено администрации, ответ придет в течении нескольких дней',)
    log_message(call.message.from_user.id, {'function': 'write_to_support', 'message': str(call.message)})


@dp.message_handler(state=Support_Message.from_user)
async def support_process_name(message: types.Message, state: FSMContext):

    async with state.proxy() as data:
        data['from_user'] = message.from_user.id

    async with state.proxy() as data:
        data['message'] = message.text

    async with state.proxy() as data:
        forwarded = await message.forward(chat_id=TELEGRAM_SUPPORT_CHAT_ID)
        await bot.send_message(
            chat_id=TELEGRAM_SUPPORT_CHAT_ID,
            reply_to_message_id=forwarded.message_id,
            text=f"""@{message.from_user.username}\nОбратился в поддержку\nСообщение: {data['message']}"""
        )

    await state.finish()
    # await message.reply('Ваше сообщение обробатывается, вам напишут')

    keyboard_text, keyboard_image, reply_markup = ans.keyboard()
    await message.answer('Ваше сообщение обробатывается, вам напишут', reply_markup=reply_markup)

    log_message(message.from_user.id, {'function': 'process_name', 'message': str(message)})



# ---------------------------Work---------------------------
@dp.message_handler(commands=['work'])
@dp.message_handler(filters.Text(contains=ans.MAIN_KEYBOARD()['work']))
async def work(message: types.Message):
    message_text, message_image = ans.work()

    if not message_image:
        await message.answer(message_text)
    else:
        await message.answer_photo(InputFile(message_image), message_text)


# ---------------------------Other---------------------------
async def on_startup(dp):
    await bot.set_webhook(WEBHOOK_URL, drop_pending_updates=True)
    logging.warning(await bot.get_webhook_info())
    # insert code here to run it after start


async def on_shutdown(dp):
    logging.warning('Shutting down..')

    await bot.delete_webhook()
    logging.warning('Bye!')



@dp.message_handler(commands=['12345'])
async def admin(message: types.Message):
    owner = False
    admin = False
    if any([True for i in owners() if f"{message.from_user.id}" == i[0]]):
        owner = True
    if any([True for i in admins() if f"{message.from_user.id}" == i[0]]):
        admin = True

    if owner or admin:
        text = f'Админ панель'
        inline_keyboard = [
            [InlineKeyboardButton(text=('0123456789' * 60), callback_data='make_new_thing')]
        ]
        menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)
        await message.answer(text, reply_markup=menu)


# def main():
#     def set_hook():
#         import asyncio
#         from bot_start import HEROKU_APP_NAME, WEBHOOK_URL, Telegram_Token
#         from aiogram import Bot
#         bot = Bot(token=Telegram_Token)
#
#         async def hook_set():
#             if not HEROKU_APP_NAME:
#                 print('You have forgot to set HEROKU_APP_NAME')
#                 quit()
#             await bot.set_webhook(WEBHOOK_URL)
#             print(await bot.get_webhook_info())
#
#         asyncio.run(hook_set())
#         bot.close()
#
#     def start():
#         from bot.bot import main
#         main()


if __name__ == '__main__':
    executor.start_polling(dp)
    # logging.basicConfig(level=logging.INFO)
    # start_webhook(
    #     dispatcher=dp,
    #     webhook_path=WEBHOOK_PATH,
    #     skip_updates=True,
    #     on_startup=on_startup,
    #     on_shutdown=on_shutdown,
    #     host=WEBAPP_HOST,
    #     port=WEBAPP_PORT,
    # )

