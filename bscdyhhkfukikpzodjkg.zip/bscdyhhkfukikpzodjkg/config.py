import os
import pickle


# messages and keyboards
# MESSAGE_START = "Start message"
MESSAGE_USE_KEYBOARD = 'Взаимодейству с ботом через клавиатуру, если она не отображается используй коммануд /start еще раз'
MESSAGE_SUPPORT = 'Поддержка'

MESSAGE_WORK_FILE = 'work.pickle'
MESSAGE_WORK_IMAGE_FILE = 'work_img.pickle'

MAIN_KEYBOARD = {'profile': 'Профиль', 'market': 'Товары', 'support': 'Поддержка', 'work': 'Работа', 'review': 'Отзывы'}
DECLINE_KEYBOARD = {'decline': '⬅ Отменить'}


Telegram_Token = "5320309968:AAGHmyDMY8AH0hcbDb_WNYZoS8dYH6CxxbQ"

BLOCK_CYPHER_TOKEN = "2cbc62b0e5c44cefa21e13450b2a4fe0"

Main_Wallet_Pickle = 'w.pickle'
TELEGRAM_SUPPORT_CHAT_PICKLE = 'tsc.pickle'
REVIEW_PICKLE_FILE = 'review.pickle'
MESSAGE_START_PICKLE = 'message_start.pickle'

SUPPORT_CHANEL_MESSAGE_PICKLE = 'support_chanel.pickle'
SUPPORT_MONEY_MESSAGE_PICKLE = 'support_money.pickle'


Database_Name = 'db.db'
Statistic_Database_Name = 'stat.db'
Admins_Database_Name = 'admin.db'
Database_Path = f"{os.path.dirname(__file__)}"
Drop_Database = False

# database
if not os.path.exists(os.path.join(Database_Path, Database_Name)):
    pass

# pickle
if not os.path.exists(os.path.join(os.path.dirname(__file__), SUPPORT_CHANEL_MESSAGE_PICKLE)):
    with open(os.path.join(os.path.dirname(__file__), SUPPORT_CHANEL_MESSAGE_PICKLE), 'wb') as f:
        pickle.dump("t.me/", f)

if not os.path.exists(os.path.join(os.path.dirname(__file__), SUPPORT_MONEY_MESSAGE_PICKLE)):
    with open(os.path.join(os.path.dirname(__file__), SUPPORT_MONEY_MESSAGE_PICKLE), 'wb') as f:
        pickle.dump("t.me/", f)

if not os.path.exists(os.path.join(os.path.dirname(__file__), MESSAGE_START_PICKLE)):
    with open(os.path.join(os.path.dirname(__file__), MESSAGE_START_PICKLE), 'wb') as f:
        pickle.dump("Start message", f)

if not os.path.exists(os.path.join(os.path.dirname(__file__), REVIEW_PICKLE_FILE)):
    with open(os.path.join(os.path.dirname(__file__), REVIEW_PICKLE_FILE), 'wb') as f:
        pickle.dump('t.me/reeeeeview', f)

if not os.path.exists(os.path.join(os.path.dirname(__file__), Main_Wallet_Pickle)):
    with open(os.path.join(os.path.dirname(__file__), Main_Wallet_Pickle), 'wb') as f:
        pickle.dump('18SQsofQGmBSD2uvjkxokgHiW8k76bniXp', f)

with open(os.path.join(os.path.dirname(__file__), Main_Wallet_Pickle), 'rb') as f:
    Main_Wallet_Address = pickle.load(f)

with open(os.path.join(os.path.dirname(__file__), TELEGRAM_SUPPORT_CHAT_PICKLE), 'rb') as f:
    TELEGRAM_SUPPORT_CHAT_ID = pickle.load(f)

if not os.path.exists(os.path.join(os.path.dirname(__file__), TELEGRAM_SUPPORT_CHAT_PICKLE)):
    with open(os.path.join(os.path.dirname(__file__), TELEGRAM_SUPPORT_CHAT_PICKLE), 'wb') as f:
        TELEGRAM_SUPPORT_CHAT_ID = '-761910624'
        pickle.dump(TELEGRAM_SUPPORT_CHAT_ID, f)

if not os.path.exists(os.path.join(os.path.dirname(__file__), MESSAGE_WORK_FILE)):
    with open(os.path.join(os.path.dirname(__file__), MESSAGE_WORK_FILE), 'wb') as f:
        MESSAGE_WORK = 'Описание работы'
        pickle.dump(MESSAGE_WORK, f)

if not os.path.exists(os.path.join(os.path.dirname(__file__), MESSAGE_WORK_IMAGE_FILE)):
    with open(os.path.join(os.path.dirname(__file__), MESSAGE_WORK_IMAGE_FILE), 'wb') as f:
        MESSAGE_WORK_IMG = False
        pickle.dump(MESSAGE_WORK_IMG, f)

with open(os.path.join(os.path.dirname(__file__), MESSAGE_WORK_FILE), 'rb') as f:
    MESSAGE_WORK = pickle.load(f)


with open(os.path.join(os.path.dirname(__file__), MESSAGE_WORK_IMAGE_FILE), 'rb') as f:
    MESSAGE_WORK_IMG = pickle.load(f)


with open(os.path.join(os.path.dirname(__file__), SUPPORT_CHANEL_MESSAGE_PICKLE), 'rb') as f:
    SUPPORT_CHANEL_MESSAGE = pickle.load(f)

with open(os.path.join(os.path.dirname(__file__), SUPPORT_MONEY_MESSAGE_PICKLE), 'rb') as f:
    SUPPORT_MONEY_MESSAGE = pickle.load(f)


with open(os.path.join(os.path.dirname(__file__), REVIEW_PICKLE_FILE), 'rb') as f:
    REVIEW_CHANEL = pickle.load(f)

with open(os.path.join(os.path.dirname(__file__), MESSAGE_START_PICKLE), 'rb') as f:
    MESSAGE_START = pickle.load(f)

dirs = ['admin', 'media', 'qr', 'things']
for d in dirs:
    if not os.path.exists(os.path.join(os.path.dirname(__file__), d)):
        mode = 0o666
        path = os.path.join(os.path.join(os.path.dirname(__file__), d))
        os.makedirs(path, mode)


def all_resume():
    global Main_Wallet_Address, TELEGRAM_SUPPORT_CHAT_ID, MESSAGE_WORK, MESSAGE_WORK_IMG, REVIEW_CHANEL, MESSAGE_START

    if not os.path.exists(os.path.join(os.path.dirname(__file__), SUPPORT_CHANEL_MESSAGE_PICKLE)):
        with open(os.path.join(os.path.dirname(__file__), SUPPORT_CHANEL_MESSAGE_PICKLE), 'wb') as f:
            pickle.dump("t.me/", f)

    if not os.path.exists(os.path.join(os.path.dirname(__file__), SUPPORT_MONEY_MESSAGE_PICKLE)):
        with open(os.path.join(os.path.dirname(__file__), SUPPORT_MONEY_MESSAGE_PICKLE), 'wb') as f:
            pickle.dump("t.me/", f)

    if not os.path.exists(os.path.join(os.path.dirname(__file__), MESSAGE_START_PICKLE)):
        with open(os.path.join(os.path.dirname(__file__), MESSAGE_START_PICKLE), 'wb') as f:
            pickle.dump("Start message", f)

    if not os.path.exists(os.path.join(os.path.dirname(__file__), REVIEW_PICKLE_FILE)):
        with open(os.path.join(os.path.dirname(__file__), REVIEW_PICKLE_FILE), 'wb') as f:
            pickle.dump('t.me/reeeeeview', f)

    if not os.path.exists(os.path.join(os.path.dirname(__file__), Main_Wallet_Pickle)):
        with open(os.path.join(os.path.dirname(__file__), Main_Wallet_Pickle), 'wb') as f:
            pickle.dump('18SQsofQGmBSD2uvjkxokgHiW8k76bniXp', f)

    with open(os.path.join(os.path.dirname(__file__), Main_Wallet_Pickle), 'rb') as f:
        Main_Wallet_Address = pickle.load(f)

    with open(os.path.join(os.path.dirname(__file__), TELEGRAM_SUPPORT_CHAT_PICKLE), 'rb') as f:
        TELEGRAM_SUPPORT_CHAT_ID = pickle.load(f)

    if not os.path.exists(os.path.join(os.path.dirname(__file__), TELEGRAM_SUPPORT_CHAT_PICKLE)):
        with open(os.path.join(os.path.dirname(__file__), TELEGRAM_SUPPORT_CHAT_PICKLE), 'wb') as f:
            TELEGRAM_SUPPORT_CHAT_ID = '-761910624'
            pickle.dump(TELEGRAM_SUPPORT_CHAT_ID, f)

    if not os.path.exists(os.path.join(os.path.dirname(__file__), MESSAGE_WORK_FILE)):
        with open(os.path.join(os.path.dirname(__file__), MESSAGE_WORK_FILE), 'wb') as f:
            MESSAGE_WORK = 'Описание работы'
            pickle.dump(MESSAGE_WORK, f)

    with open(os.path.join(os.path.dirname(__file__), MESSAGE_WORK_FILE), 'rb') as f:
        MESSAGE_WORK = pickle.load(f)

    if not os.path.exists(os.path.join(os.path.dirname(__file__), MESSAGE_WORK_IMAGE_FILE)):
        with open(os.path.join(os.path.dirname(__file__), MESSAGE_WORK_IMAGE_FILE), 'wb') as f:
            MESSAGE_WORK_IMG = False
            pickle.dump(MESSAGE_WORK_IMG, f)

    with open(os.path.join(os.path.dirname(__file__), MESSAGE_WORK_IMAGE_FILE), 'rb') as f:
        MESSAGE_WORK_IMG = pickle.load(f)

    with open(os.path.join(os.path.dirname(__file__), REVIEW_PICKLE_FILE), 'rb') as f:
        REVIEW_CHANEL = pickle.load(f)

    with open(os.path.join(os.path.dirname(__file__), MESSAGE_START_PICKLE), 'rb') as f:
        MESSAGE_START = pickle.load(f)

    with open(os.path.join(os.path.dirname(__file__), SUPPORT_CHANEL_MESSAGE_PICKLE), 'rb') as f:
        SUPPORT_CHANEL_MESSAGE = pickle.load(f)

    with open(os.path.join(os.path.dirname(__file__), SUPPORT_MONEY_MESSAGE_PICKLE), 'rb') as f:
        SUPPORT_MONEY_MESSAGE = pickle.load(f)

    dirs = ['admin', 'media', 'qr', 'things']
    for d in dirs:
        if not os.path.exists(os.path.join(os.path.dirname(__file__), d)):
            mode = 0o666
            path = os.path.join(os.path.join(os.path.dirname(__file__), d))
            os.makedirs(path, mode)

def supp_chanel():
    with open(os.path.join(os.path.dirname(__file__), SUPPORT_CHANEL_MESSAGE_PICKLE), 'rb') as f:
        SUPPORT_CHANEL_MESSAGE = pickle.load(f)
    return SUPPORT_CHANEL_MESSAGE

def supp_money():
    with open(os.path.join(os.path.dirname(__file__), SUPPORT_MONEY_MESSAGE_PICKLE), 'rb') as f:
        SUPPORT_MONEY_MESSAGE = pickle.load(f)
    return SUPPORT_MONEY_MESSAGE

def msg_start():
    with open(os.path.join(os.path.dirname(__file__), MESSAGE_START_PICKLE), 'rb') as f:
        MESSAGE_START = pickle.load(f)
    return MESSAGE_START

def msg_work():
    with open(os.path.join(os.path.dirname(__file__), MESSAGE_WORK_FILE), 'rb') as f:
        MESSAGE_WORK = pickle.load(f)
    return MESSAGE_WORK

def msg_work_img():
    with open(os.path.join(os.path.dirname(__file__), MESSAGE_WORK_IMAGE_FILE), 'rb') as f:
        MESSAGE_WORK_IMG = pickle.load(f)
    return MESSAGE_WORK_IMG

def msg_review():
    with open(os.path.join(os.path.dirname(__file__), REVIEW_PICKLE_FILE), 'rb') as f:
        REVIEW_CHANEL = pickle.load(f)
    return REVIEW_CHANEL
