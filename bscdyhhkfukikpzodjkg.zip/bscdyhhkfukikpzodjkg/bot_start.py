from database import *
from btc import *

from config import *
import qrcode

import aiogram
from aiogram import Bot, Dispatcher, executor, types

from aiogram.types.inline_keyboard import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from aiogram.types import InputFile

from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.contrib.middlewares.logging import LoggingMiddleware
from aiogram.dispatcher import FSMContext, filters
from aiogram.utils.callback_data import CallbackData

import os

import logging


class Answers:
    def __init__(self):
        pass

    # ___________________________________ keyboards ___________________________________
    def MAIN_KEYBOARD(self):
        return MAIN_KEYBOARD

    def DECLINE_KEYBOARD(self):
        return DECLINE_KEYBOARD

    def keyboard(self):
        keyboard = [
            [KeyboardButton(text=MAIN_KEYBOARD['market']), KeyboardButton(text=MAIN_KEYBOARD['profile'])],
            [KeyboardButton(text=MAIN_KEYBOARD['work']), KeyboardButton(text=MAIN_KEYBOARD['support'])],
            [KeyboardButton(text=MAIN_KEYBOARD['review'])],
        ]

        menu = ReplyKeyboardMarkup(keyboard=keyboard, resize_keyboard=True)
        return MESSAGE_USE_KEYBOARD, os.path.join(os.path.dirname(__file__), "media/file.gif"), menu

    # ___________________________________ start ___________________________________
    def start(self):
        return msg_start()

    # ___________________________________ profile ___________________________________
    def profile_message(self, info):
        text = f"🧑‍🔧Профиль:\n\nКоличество покупок: {len(info['things']) - 1}\nДата регистрации: {datetime.datetime.strptime((info['register_date']), '%Y-%m-%d %H:%M:%S.%f').strftime('%d.%m %Y')}"
        # datetime.datetime.strptime(i[4], '%Y-%m-%d %H:%M:%S.%f')
        inline_keyboard = [
            [InlineKeyboardButton(text='Покупки', callback_data='things_basket')],
            [InlineKeyboardButton(text='Транзакции RUB', callback_data='transactions'), InlineKeyboardButton(text='Транзакции BTC', callback_data='btc_transactions')],
        ]
        # menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)
        menu = None

        # return f"🧑‍🔧Профиль:\n\n" \
        #         f"Количество RUB: {info['gg_coin_balance']}\n" \
        #        f"Количество BTC: {info['btc_balance']}\n" \
        #        f"Количество покупок: {len(info['things']) - 1}\n" \
        #         f"Дата регистрации: {info['register_date']}", menu
        return text, menu

    def things_basket(self, info):
        db = connect_exist_database()

        things = [things_info(db, i[2]) for i in info['things']]
        inline_keyboard = []

        for i in things:
            inline_keyboard.append([InlineKeyboardButton(text=f'{i["description"]}', callback_data=Thing.new(action='purchased_thing', num=i['thing_id']))])

        menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)
        return 'Покупки', menu

    def rub_transactions(self, info):
        trans = "\n".join([f"{i[1]}: {datetime.datetime.strptime(i[2], '%Y-%m-%d %H:%M:%S.%f').strftime('%I:%M  %d %B')}" for i in info['gg_coin_checks']][::-1])
        text = f"""Ruble\nБаланс: {info['gg_coin_balance']}\n\n{trans}"""

        inline_keyboard = [
            [InlineKeyboardButton(text='Пополнить RUB', callback_data='rub_add_balance')],
        ]
        # menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)
        menu = None

        return text, menu

    def btc_transactions(self, info):
        trans = "\n".join([f"{i[1]}: {datetime.datetime.strptime(i[5], '%Y-%m-%d %H:%M:%S.%f').strftime('%I:%M  %d %B')}" for i in info['btc_checks']][::-1])
        text = f"""Bitcoin\nБаланс: {info['btc_balance']}\n\n\n{trans}"""

        inline_keyboard = [
            [InlineKeyboardButton(text='Пополнить BTC', callback_data='btc_add_balance')],
        ]
        # menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)
        menu = None

        return text, menu

    # ___________________________________ balance ___________________________________
    def balance(self, info):
        text = f'RUB\nБаланс: {info["gg_coin_balance"]}\nКол-во транзакций: {len(info["gg_coin_checks"]) - 1}\n\n' \
               f'BTC\nБаланс: {info["btc_balance"]}\nКол-во транзакций: {len(info["btc_checks"]) - 1}'
        inline_keyboard = [
            [InlineKeyboardButton(text='Пополнить RUB', callback_data='rub_add_balance')],
            [InlineKeyboardButton(text='Пополнить BTC', callback_data='btc_add_balance')],
        ]
        menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)

        return text, menu

    def btc_add_balance(self, info):
        img_name = f"qr/{info['telegram_id']}_{datetime.datetime.now()}"
        img = qrcode.make(info['btc_address'])
        img.save(img_name)

        text = f"""💳Ваш адрес биткоин кошелька\n{info['btc_address']}"""

        inline_keyboard = [
            [InlineKeyboardButton(text='Подтвердить перевод', callback_data='btc_update_balance')],
        ]
        menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)


        return text, img_name, menu

    def rub_add_balance(self, info):
        # trans = "\n".join([f"{i[1]}: {datetime.datetime.strptime(i[2], '%Y-%m-%d %H:%M:%S.%f').strftime('%I:%M  %d %B')}" for i in info['gg_coin_checks']][::-1])
        # text = f"""Ruble\nБаланс: {info['gg_coin_balance']}\n\n{trans}"""
        #
        # inline_keyboard = [
        #     [InlineKeyboardButton(text='Пополнить RUB', callback_data='rub_add_balance')],
        # ]
        # menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)

        return False

    # ___________________________________ market ___________________________________
    def market(self, db, things_inf):
        # 'thing_id': None,
        # 'thing_name': None,
        # 'description': None,
        # 'images': None,
        # 'cost': {},
        # 'show_flag': 0,
        # 'date': None,
        # 'thing_exist': False,
        text = 'Выбери товар который хочешь купить'
        things = [things_info(db, i[0]) for i in things_inf]
        inline_keyboard = []

        for i in things:
            if i['show_flag']:
                inline_keyboard.append([InlineKeyboardButton(text=f'{i["thing_name"]}',
                                                             callback_data=Thing.new(action='buy_thing',
                                                                                     num=i['thing_id']))])

        if inline_keyboard == []:
            inline_keyboard = [[(InlineKeyboardButton(text=f'Пока что товаров нету', callback_data='no things'))]]
        menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)

        return text, menu

    def thing_message(self, info):
        if info['images']:
            return f'{info["description"]}\nЦена RUB: {info["cost"]["rub"]}\nЦена BTC: {"{0:.10f}".format(info["cost"]["btc"])}', info['images']

        return f'{info["description"]}\nЦена RUB: {info["cost"]["rub"]}\nЦена BTC: {"{0:.10f}".format(info["cost"]["btc"])}', False

    def buy_thing_message(self, info):
        inline_keyboard = [
            [InlineKeyboardButton(text='Купить', callback_data=Thing.new(action='buy', num=info['thing_id']))],
            [InlineKeyboardButton(text='Назад', callback_data="back_to_market")],
        ]
        menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)

        if info['images']:
            return f'{info["description"]}\nЦена RUB: {info["cost"]["rub"]}\nЦена BTC: {"{0:.10f}".format(info["cost"]["btc"])}', menu, info['images']

        return f'{info["description"]}\nЦена RUB: {info["cost"]["rub"]}\nЦена BTC: {"{0:.10f}".format(info["cost"]["btc"])}', menu, False

    def buy_thing_purchase_algorithm_1(self, info, thing, other=False):
        """
        'telegram_id': telegram_id,
        'first_name': None,
        'last_name': None,
        'user_id': None,
        # wallet operations
        'wallet_id': None,
        'wallet_owner': None,
        # gg_coin
        'gg_coin_check_id': None,
        'gg_coin_balance': None,
        'gg_coin_checks': None,
        # btc
        'btc_check_id': None,
        'btc_balance': None,
        'btc_address': None,
        'btc_wif': None,
        'btc_checks': None,
        # btc real
        'btc_real_balance': None,
        'btc_real_checks': None,
        # buying things
        'things_basket_id': None,
        'things': None,
        'register_date': None,
        'user_exist': False
        """
        text = 'Выберите способ оплаты'
        inline_keyboard = [
            [InlineKeyboardButton(text='Покупка RUB', callback_data=Buy_thing_purchase_algorithm_1.new(currency='rub', user_inf=info['telegram_id'], thing_inf=thing['thing_id'], other=other))],
            [InlineKeyboardButton(text='Покупка BTC', callback_data=Buy_thing_purchase_algorithm_1.new(currency='btc', user_inf=info['telegram_id'], thing_inf=thing['thing_id'], other=other))],
            # [InlineKeyboardButton(text='Покупка RUB', callback_data='buy_thing_purchase_algorithm_1_rub')],
            # [InlineKeyboardButton(text='Покупка RUB', callback_data='buy_thing_purchase_algorithm_1_btc')],
        ]
        menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)

        return text, menu

    def buy_thing_purchase_algorithm_2(self, info, thing):
        text = 'Выберите город'

        db = connect_exist_database()
        things = [i[0] for i in db.sql_get_from_table('cites')]
        inline_keyboard = []

        for i in things:
            inline_keyboard.append(
                [InlineKeyboardButton(text=f'{i}', callback_data=Choose_City.new(city=i, user_inf=info['telegram_id'], thing_inf=thing['thing_id']))])
            # inline_keyboard.append(
            #     [InlineKeyboardButton(text=f'{i["thing_name"]}', callback_data=Del_thing.new('del', i['thing_id']))]
            #                         )
        inline_keyboard.append([InlineKeyboardButton(text='Другой', callback_data=Choose_City.new(city='other', user_inf=info['telegram_id'], thing_inf=thing['thing_id']))])
        if inline_keyboard == []:
            inline_keyboard = [[(InlineKeyboardButton(text=f'Пока что городов нету нету', callback_data='no things'))]]
        menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)

        # inline_keyboard = [
        #     [InlineKeyboardButton(text='Москва', callback_data=Choose_City.new(city='moscow', user_inf=info['telegram_id'], thing_inf=thing['thing_id']))],
        #     [InlineKeyboardButton(text='Санкт-Петербург', callback_data=Choose_City.new(city='saint_petersburg', user_inf=info['telegram_id'], thing_inf=thing['thing_id']))],
        #     [InlineKeyboardButton(text='Другой', callback_data=Choose_City.new(city='other', user_inf=info['telegram_id'], thing_inf=thing['thing_id']))],
        # ]
        menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)

        return text, menu

    def buy_thing_purchase_algorithm_2_city_other(self):
        text = 'Укажите город доставки'
        keyboard = [
            [KeyboardButton(text=DECLINE_KEYBOARD['decline'])]
        ]

        menu = ReplyKeyboardMarkup(keyboard=keyboard, resize_keyboard=True)

        return text, menu

    def buy_thing_purchase_algorithm_2_city(self):
        text = 'Ожидайте...'
        keyboard = [
            [KeyboardButton(text=MAIN_KEYBOARD['market']), KeyboardButton(text=MAIN_KEYBOARD['profile'])],
            [KeyboardButton(text=MAIN_KEYBOARD['work']), KeyboardButton(text=MAIN_KEYBOARD['support'])],
            [KeyboardButton(text=MAIN_KEYBOARD['review'])],

        ]

        menu = ReplyKeyboardMarkup(keyboard=keyboard, resize_keyboard=True)

        return text, menu

    def buy_thing(self, user_inf, thing_inf, other=False):
        # print(user_inf, thing_inf, other)
        text = 'Выберите способ оплаты'
        keyboard = [
            [InlineKeyboardButton(text='Покупка RUB', callback_data=Buy_thing.new('rub', user_inf['telegram_id'], thing_inf['thing_id'], other))],
            [InlineKeyboardButton(text='Покупка BTC', callback_data=Buy_thing.new('btc', user_inf['telegram_id'], thing_inf['thing_id'], other))],
        ]
        inline_menu = InlineKeyboardMarkup(inline_keyboard=keyboard)

        return text, inline_menu


    def review(self):
        text = 'Отзывы'
        inline_keyboard = [
            # [InlineKeyboardButton(text='Проблемы с оплатой', callback_data='write to support')].
            # [InlineKeyboardButton(text='Обратится в поддержку', callback_data='write to support')].
            [InlineKeyboardButton(text='Проблемы с оплатой', url=msg_review())],
        ]
        print(msg_review())
        menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)
        return text, menu


    # ___________________________________ support ___________________________________
    def support(self):
        inline_keyboard = [
            # [InlineKeyboardButton(text='Проблемы с оплатой', callback_data='write to support')].
            # [InlineKeyboardButton(text='Обратится в поддержку', callback_data='write to support')].
            [InlineKeyboardButton(text='Проблемы с оплатой', url=supp_money())],
            [InlineKeyboardButton(text='Остальные вопросы', url=supp_chanel())],
        ]
        menu = InlineKeyboardMarkup(inline_keyboard=inline_keyboard)
        return MESSAGE_SUPPORT, menu

    def decline_support(self):
        keyboard = [
            [KeyboardButton(text=DECLINE_KEYBOARD['decline'])],
        ]
        menu = ReplyKeyboardMarkup(keyboard=keyboard, resize_keyboard=True)
        return "Вы обратились в поддержку...", menu

    # ___________________________________ work ___________________________________
    def work(self):
        return msg_work(), msg_work_img()


logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO
)

logger = logging.getLogger(__name__)
storage = MemoryStorage()

HEROKU_APP_NAME = 'quiet-plains-98765'
WEBAPP_HOST = '0.0.0.0'
WEBAPP_PORT = int(os.environ.get('PORT', 5000))

# webhook settings
WEBHOOK_HOST = f'https://{HEROKU_APP_NAME}.herokuapp.com'
WEBHOOK_PATH = f'/webhook/{Telegram_Token}'
WEBHOOK_URL = f'{WEBHOOK_HOST}{WEBHOOK_PATH}'

bot = Bot(token=Telegram_Token)
dp = Dispatcher(bot, storage=storage)
# dp.middleware.setup(LoggingMiddleware())

Thing = CallbackData('thing', 'action', 'num')

Choose_City = CallbackData('choose', 'user_inf', 'thing_inf', 'city')
Buy_thing_purchase_algorithm_1 = CallbackData('BUY', 'currency', 'user_inf', 'thing_inf')
Buy_thing_purchase_algorithm_2 = CallbackData('BUY', 'currency', 'user_inf', 'thing_inf', 'city', 'address', 'other')
Buy_thing_purchase_algorithm_3 = CallbackData('BUY', 'currency', 'user_inf', 'thing_inf', 'file_path')
BUY = CallbackData('BUY', 'currency', 'wallet', 'user_inf', 'thing_inf', 'other')

Del_thing = CallbackData('del_thing', 'action', 'num')
Del_city = CallbackData('del_thing', 'action', 'city')
Del_btc_wallet = CallbackData('Del_btc_wallet', 'action', 'wallet')
Del_rub_wallet = CallbackData('Del_rub_wallet', 'action', 'wallet')
Del_admin = CallbackData('del_thing', 'action', 'telegram_id')



Buy_thing = CallbackData('FINAL_BUY', 'currency', 'user_inf', 'thing_inf', 'other')

ans = Answers()
