import os
import sqlite3
import datetime
import os

import plotly.graph_objects as go
import numpy as np


class Database:
    def __init__(self, main_path, database):
        if os.path.exists(main_path):
            self.main_path = main_path
        else:
            raise FileExistsError
        self.database = database

    def sql_table_list(self):
        con = sqlite3.connect(os.path.join(self.main_path, f"{self.database}"))
        cur = con.cursor()
        table_list = []
        for i in cur.execute(f"""SELECT name FROM sqlite_master WHERE type='table'""").fetchall():
            # cur.execute(f"""DROP TABLE IF EXISTS {i[0]}""")
            table_list.append(i[0])
        return table_list

    def sql_create_table(self, table_name: str, columns: list):
        con = sqlite3.connect(os.path.join(self.main_path, f"{self.database}"))
        cur = con.cursor()
        # check if table already exist
        res = [i[0] for i in cur.execute(f"""SELECT name FROM sqlite_master WHERE type='table'""").fetchall()]
        if table_name in res:
            return False
        else:
            cur.execute(f"""CREATE TABLE {table_name} ({', '.join([str(i) for i in columns])})""")
            return True

    def sql_drop_table(self, table_name: str):
        con = sqlite3.connect(os.path.join(self.main_path, f"{self.database}"))
        cur = con.cursor()
        # check if table already exist
        if table_name == 'all':
            for i in cur.execute(f"""SELECT name FROM sqlite_master WHERE type='table'""").fetchall():
                cur.execute(f"""DROP TABLE IF EXISTS {i[0]}""")
        else:
            res = [i[0] for i in cur.execute(f"""DROP TABLE IF EXISTS {table_name}""").fetchall()]

    def sql_get_from_table(self, table_name, columns='*'):
        con = sqlite3.connect(os.path.join(self.main_path, f"{self.database}"))
        cur = con.cursor()
        res = [i[0] for i in cur.execute(f"""SELECT name FROM sqlite_master WHERE type='table'""").fetchall()]
        if table_name in res:
            if columns == '*':
                result = [i for i in cur.execute(f"""SELECT {columns} FROM {table_name}""").fetchall()]
                return result
            result = [i for i in cur.execute(
                f"""SELECT {", ".join([str(i) for i in columns])} FROM {table_name}""").fetchall()]
            return result
        else:
            return False

    def sql_insert_into_table(self, table, insert_info: list):
        con = sqlite3.connect(os.path.join(self.main_path, f"{self.database}"))
        cur = con.cursor()

        cur.execute(f"""INSERT INTO {table} VALUES ({('?, '*len(insert_info))[:-2]})""", insert_info)
        result = [i for i in cur.execute(f"""SELECT * FROM {table}""")]
        con.commit()
        con.close()
        return result

    def sql_del_from_table(self, table, delete_info):
        con = sqlite3.connect(os.path.join(self.main_path, f"{self.database}"))
        cur = con.cursor()

        cur.execute(f"""DELETE FROM {table} WHERE {delete_info[0]} = '{delete_info[1]}'""")

        result = [i for i in cur.execute(f"""SELECT * FROM {table}""")]
        con.commit()
        con.close()
        return result

    def html_name(self, count):
        return [count+1, os.path.join(self.main_path, f"{count+1}.html")]


def make_stats(data: list, photo_name, dir='admin') -> str:
    if not os.path.exists(dir):
        os.mkdir(dir)
    # x = np.arange(0, 30)
    #
    # dates = dcc.DatePickerRange(
    #     start_date=(datetime.date.today() - datetime.timedelta(days=30)),
    #     end_date=datetime.date.today(),
    #     display_format='MMM Do, YY',
    #     start_date_placeholder_text='MMM Do, YY'
    # )
    # print(dates)
    # px.scatter(x=dates, y=x).write_image("images/fig1.png")

    # fig.write_image("images/fig1.png")
    # def f(x):
    #     print(x**2)
    #     y = x * 10
    #     return y // x
    # fig = px.line(x=dates, y=x)
    # fig.write_image("images/fig1.png")
    x = np.arange(0, 30, 1)
    # y = [random.randrange(0, 100) for i in range(30)]

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=x, y=data))

    fig.write_image(f"{dir}/{photo_name}.png")
    return f'{dir}/{photo_name}.png'


if __name__ == '__main__':
    db = Database(os.path.dirname(__file__), 'db.db')
    db.sql_del_from_table('things', ['thing_id', '10'])
    # db.sql_drop_table('all')
    # db.sql_create_table('rest', ['dfasf', 'hjgkf'])
    # for i in range(10):
    #     db.sql_insert_into_table('rest', [f"{i}", f"{i + 1}"])
    # print(db.sql_del_from_table('rest', ['dfasf', '5']))