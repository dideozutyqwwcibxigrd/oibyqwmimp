import random

from config import *
from btc import *
from api import Database

import time
import datetime
import json


# ________________________________ admin database ________________________________
def create_admin_db():
    db = Database(Database_Path, Admins_Database_Name)
    db.sql_drop_table('all')
    # error
    db.sql_create_table('admin', ['telegram_id', 'time'])
    db.sql_create_table('owner', ['telegram_id', 'time'])
    db.sql_create_table('btc_wallets', ['address', 'time'])
    db.sql_create_table('rub_wallets', ['card_number', 'time'])

    return db


def get_all_btc_wallets():
    db = connect_admin_db()
    return db.sql_get_from_table('btc_wallets')


def get_all_rub_wallets():
    db = connect_admin_db()
    return db.sql_get_from_table('rub_wallets')


def add_new_btc_wallet(address):
    db = connect_admin_db()
    db.sql_insert_into_table('btc_wallets', [address, datetime.datetime.now()])
    return db.sql_get_from_table('btc_wallets')


def del_btc_wallet(address):
    db = connect_admin_db()
    db.sql_del_from_table('btc_wallets', ['address', f'{address}'])
    return db.sql_get_from_table('btc_wallets')


def add_new_rub_wallet(address):
    db = connect_admin_db()
    db.sql_insert_into_table('rub_wallets', [address, datetime.datetime.now()])
    return db.sql_get_from_table('rub_wallets')


def del_rub_wallet(card_number):
    db = connect_admin_db()
    print('rub_wallets', ['card_number', f'{card_number}'])
    db.sql_del_from_table('rub_wallets', ['card_number', f'{card_number}'])
    return db.sql_get_from_table('rub_wallets')


def connect_admin_db():
    db = Database(Database_Path, Admins_Database_Name)
    return db


def admin_new(telegram_id):
    db = connect_admin_db()
    db.sql_insert_into_table('admin', [str(telegram_id), datetime.datetime.now()])
    return db.sql_get_from_table('admin')


def admin_new_owner(telegram_id):
    db = connect_admin_db()
    db.sql_insert_into_table('owner', [str(telegram_id), datetime.datetime.now()])
    return db.sql_get_from_table('owner')


def admins():
    db = connect_admin_db()
    admins = db.sql_get_from_table('admin')
    return admins


def owners():
    db = connect_admin_db()
    owners = db.sql_get_from_table('owner')
    return owners


# ________________________________ logs database ________________________________
def create_statistic_db():
    db = Database(Database_Path, Statistic_Database_Name)
    db.sql_drop_table('all')
    # error
    db.sql_create_table('errors', ['error', 'time'])
    # user
    db.sql_create_table('user_new', ['telegram_id', 'json', 'time'])
    db.sql_create_table('user_messages', ['user_id', 'json', 'time'])
    # market
    db.sql_create_table('market_checks', ['user_id', 'time'])
    db.sql_create_table('thing_checks', ['user_id', 'thing_id', 'time'])
    db.sql_create_table('buys', ['user_id', 'thing_id', 'price', 'currency', 'time'])
    # wallet
    db.sql_create_table('wallet_balance_check', ['user_id', 'time'])
    db.sql_create_table('wallet_not_refills', ['user_id', 'time'])
    db.sql_create_table('wallet_refills', ['user_id', 'delta', 'time'])

    return db


def connect_log_db():
    db = Database(Database_Path, Statistic_Database_Name)
    return db


# error
def log_error(error):
    db = connect_log_db()
    db.sql_insert_into_table('errors', [str(error), datetime.datetime.now()])
    return db.sql_get_from_table('errors')


# user
def log_new_user(telegram_id, json):
    db = connect_log_db()
    db.sql_insert_into_table('user_new', [str(telegram_id), str(json), datetime.datetime.now()])
    return db.sql_get_from_table('user_new')


def log_message(user_id, json):
    db = connect_log_db()
    db.sql_insert_into_table('user_messages', [str(user_id), str(json), datetime.datetime.now()])
    return db.sql_get_from_table('user_messages')


# market
def log_market_check(user_id):
    db = connect_log_db()
    db.sql_insert_into_table('market_checks', [str(user_id), datetime.datetime.now()])
    return db.sql_get_from_table('market_checks')


def log_market_thing_check(user_id, thing_id):
    db = connect_log_db()
    db.sql_insert_into_table('thing_checks', [str(user_id), str(thing_id), datetime.datetime.now()])
    return db.sql_get_from_table('thing_checks')


def log_market_new_buy(user_id, thing_id, price, currency):
    db = connect_log_db()
    db.sql_insert_into_table('buys', [str(user_id), str(thing_id), str(price), str(currency), datetime.datetime.now()])
    return db.sql_get_from_table('buys')


# wallet
def log_wallet_balance_check(user_id):
    db = connect_log_db()
    db.sql_insert_into_table('wallet_balance_check', [str(user_id), str(json), datetime.datetime.now()])
    return db.sql_get_from_table('wallet_balance_check')


def log_wallet_not_refill(user_id):
    db = connect_log_db()
    db.sql_insert_into_table('wallet_not_refills', [str(user_id), str(json), datetime.datetime.now()])
    return db.sql_get_from_table('wallet_not_refills')


def log_wallet_refill(user_id, delta):
    db = connect_log_db()
    db.sql_insert_into_table('wallet_refills', [str(user_id), str(delta), str(json), datetime.datetime.now()])
    return db.sql_get_from_table('wallet_refills')


def read_log_error():
    db = connect_log_db()
    return db.sql_get_from_table('errors')


# user
def read_log_new_user():
    db = connect_log_db()
    return db.sql_get_from_table('user_new')


def read_log_message():
    db = connect_log_db()
    return db.sql_get_from_table('user_messages')


# market
def read_log_market_check():
    db = connect_log_db()
    return db.sql_get_from_table('market_checks')


def read_log_market_thing_check():
    db = connect_log_db()
    return db.sql_get_from_table('thing_checks')


def read_log_market_new_buy():
    db = connect_log_db()
    return db.sql_get_from_table('buys')


# wallet
def read_log_wallet_balance_check():
    db = connect_log_db()
    return db.sql_get_from_table('wallet_balance_check')


def read_log_wallet_not_refill():
    db = connect_log_db()
    return db.sql_get_from_table('wallet_not_refills')


def read_log_wallet_refill():
    db = connect_log_db()
    return db.sql_get_from_table('wallet_refills')


# ________________________________ main database ________________________________
def create_new_database():
    db = Database(Database_Path, Database_Name)
    db.sql_drop_table('all')
    db.sql_create_table('users', ['id', 'telegram_id', 'first_name', 'last_name', 'wallet_id', 'things_basket_id', 'register_date'])
    # wallets
    db.sql_create_table('wallets', ['wallet_id', 'owner', 'check_id', 'btc_check_id', 'register_date'])
    db.sql_create_table('checks', ['wallet_id', 'amount', 'date'])
    db.sql_create_table('btc_checks', ['wallet_id', 'balance', 'address', 'wif', 'btc_sent', 'date'])
    # things
    db.sql_create_table('things_baskets', ['basket_id', 'owner', 'thing_id', 'buy_date'])
    db.sql_create_table('things', ['thing_id', 'thing_name', 'description', 'images', 'costs_json', 'show_flag', 'purshase_algorithm', 'date'])
    db.sql_create_table('cites', ['city', 'date'])
    # none thing
    db.sql_insert_into_table('things', [0, 'start thing', None, None, f"{({'gg_coins': 0, 'btc': 0})}", False, 0, datetime.datetime.now()])
    db.sql_insert_into_table('cites', ['Москва', datetime.datetime.now()])
    db.sql_insert_into_table('cites', ['Санкт Петербург', datetime.datetime.now()])
    return db


def connect_exist_database():
    db = Database(Database_Path, Database_Name)
    return db


def add_new_city(city):
    db = connect_exist_database()
    db.sql_insert_into_table('cites', [city, datetime.datetime.now()])
    return db.sql_get_from_table('cites')


def del_city(city):
    db = connect_exist_database()
    db.sql_del_from_table('cites', ['city', f'{city}'])
    return db.sql_get_from_table('cites')


def all_user_telegram_id():
    db = connect_exist_database()
    return [i[1] for i in db.sql_get_from_table('users')]


def create_user(db, telegram_id, first_name, last_name):
    result = {"user_id": None,
                "telegram_id": telegram_id,
                "first_name": first_name,
                "last_name": last_name,
                "wallet_id": None,
                "basket_id": None,
                "date": datetime.datetime.now(),
                "user_already_exist": True
                }
    make_new_user = False

    users_db = db.sql_get_from_table('users')
    wallets_db = db.sql_get_from_table('wallets')
    checks_db = db.sql_get_from_table('checks')
    btc_checks_db = db.sql_get_from_table('btc_checks')
    things_basket_db = db.sql_get_from_table('things_baskets')

    if not any([True for i in users_db if i[1] == telegram_id]):
        make_new_user = True
        result['user_already_exist'] = False
    else:
        return result

    if make_new_user:
        if users_db == []:
            user_id = 0
        else:
            user_id = max([i[0] for i in users_db]) + 1

        if wallets_db == []:
            wallets_id = 0
        else:
            wallets_id = max([i[0] for i in wallets_db]) + 1

        if checks_db == []:
            checks_id = 0
        else:
            checks_id = max([i[0] for i in checks_db]) + 1

        if btc_checks_db == []:
            btc_checks_id = 0
        else:
            btc_checks_id = max([i[0] for i in checks_db]) + 1

        # btc_address, btc_wif = create_wallet(btc_checks_id, main_wallet['seed'])
        btc_address, btc_wif = None, None

        if things_basket_db == []:
            basket_id = 0
        else:
            basket_id = max([i[0] for i in things_basket_db]) + 1

        db.sql_insert_into_table('users', [user_id, telegram_id, first_name, last_name, wallets_id, basket_id, datetime.datetime.now()])
        db.sql_insert_into_table('wallets', [wallets_id, user_id, checks_id, btc_checks_id, datetime.datetime.now()])
        db.sql_insert_into_table('things_baskets', [basket_id, user_id, 0, datetime.datetime.now()])
        db.sql_insert_into_table('checks', [wallets_id, 0, datetime.datetime.now()])
        db.sql_insert_into_table('btc_checks', [wallets_id, 0, btc_address, btc_wif, False, datetime.datetime.now()])

        result['user_id'] = user_id
        result['wallets_id'] = wallets_id
        result['basket_id'] = basket_id
        return result


def user_all_info(db, telegram_id, real_wallet_inf=False):
    result = {
        'telegram_id': telegram_id,
        'first_name': None,
        'last_name': None,
        'user_id': None,
        # wallet operations
        'wallet_id': None,
        'wallet_owner': None,
        # gg_coin
        'gg_coin_check_id': None,
        'gg_coin_balance': None,
        'gg_coin_checks': None,
        # btc
        'btc_check_id': None,
        'btc_balance': None,
        'btc_address': None,
        'btc_wif': None,
        'btc_checks': None,
        # btc real
        'btc_real_balance': None,
        'btc_real_checks': None,
        # buying things
        'things_basket_id': None,
        'things': None,
        'register_date': None,
        'user_exist': False
    }
    users_db = db.sql_get_from_table('users')
    wallets_db = db.sql_get_from_table('wallets')
    checks_db = db.sql_get_from_table('checks')
    btc_checks_db = db.sql_get_from_table('btc_checks')
    things_basket_db = db.sql_get_from_table('things_baskets')

    user = ([i for i in users_db if i[1] == telegram_id])
    try:
        u_id, t, f_n, l_n, w_id, tb_id, r_date = user[-1]

        result['user_id'] = u_id
        result['first_name'] = f_n
        result['last_name'] = l_n
        result['wallet_id'] = w_id
        result['things_basket_id'] = tb_id
        result['register_date'] = r_date
        result['user_exist'] = True
    except:
        return result

    wallet = ([i for i in wallets_db if i[0] == w_id])
    try:
        t, w_owner, ch_id, btc_ch_id, t = wallet[-1]

        result['wallet_owner'] = w_owner

        result['gg_coin_check_id'] = ch_id

        result['btc_check_id'] = btc_ch_id
    except:
        pass
    checks = ([i for i in checks_db if i[0] == ch_id])
    try:
        result['gg_coin_balance'] = sum([i[1] for i in checks])
        result['gg_coin_checks'] = checks
    except:
        pass

    btc_checks = ([i for i in btc_checks_db if i[0] == btc_ch_id])
    try:
        result['btc_balance'] = sum([i[1] for i in btc_checks])
        result['btc_address'] = btc_checks[0][2]
        result['btc_wif'] = btc_checks[0][3]
        result['btc_checks'] = btc_checks

        # real = wallet_balance(result['btc_address'])
        # result['btc_real_balance'] = real['balance']
        # result['btc_real_checks'] = real['transactions']
    except:
        pass

    try:
        things = ([i for i in things_basket_db if i[0] == tb_id])
        result['things'] = things
    except:
        pass
    if result['btc_address'] and real_wallet_inf:
        try:
            j = wallet_balance(result['btc_address'])
            b_r_b = j['balance']
            b_r_c = j['transactions']
            try:
                b_r_c = [(i['balance'], i['result'], i['fee']) for i in b_r_c]
            except:
                b_r_c = [(i['hash'], i['total'], i['fees']) for i in b_r_c]

            result['btc_real_balance'] = b_r_b
            result['btc_real_checks'] = b_r_c
        except Exception as e:
            print(e)
    return result


def things_info(db, thing_id):
    result = {
        'thing_id': None,
        'thing_name': None,
        'description': None,
        'images': None,
        'cost': {},
        'show_flag': 0,
        'purchase_algorithm': None,
        'date': None,
        'thing_exist': False,
    }
    try:
        t_id, t_n, d, im, c, s_f, p_a, date = [i for i in db.sql_get_from_table('things') if i[0] == thing_id or i[0] == str(thing_id)][-1]
        result['thing_id'] = t_id
        result['thing_name'] = t_n
        result['description'] = d
        result['images'] = im
        result['cost'] = json.loads(c.replace("\'", "\""))
        result['show_flag'] = (False if s_f=='0' or s_f==0 else True)
        result['date'] = date
        result['purchase_algorithm'] = p_a
        result['thing_exist'] = True
        return result
    except Exception as e:
        return result


def refill_wallet(db: Database, wallet_id, amount):
    db.sql_insert_into_table('checks', [wallet_id, amount, datetime.datetime.now()])
    return db.sql_get_from_table('checks')


def refill_btc_wallet(db: Database, wallet_id, amount, address, wif):
    db.sql_insert_into_table('btc_checks', [wallet_id, amount, address, wif,  0, datetime.datetime.now()])
    return db.sql_get_from_table('btc_checks')


def add_thing_in_basket(db: Database, basket_id, owner, thing_id):
    db.sql_insert_into_table('things_baskets', [basket_id, owner, thing_id, datetime.datetime.now()])


def buy_thing(db: Database, telegram_id, thing_id, currency='rub', fee_kaf=1):
    result = {
        'successfully': False,
        'res': False,
        'error': False,
    }

    user = user_all_info(db, telegram_id)
    thing = things_info(db, thing_id)

    if currency == 'rub':
        pass
    elif currency == 'btc':
        add_thing_in_basket(db, user['things_basket_id'], user['user_id'], thing_id)


def add_new_thing(name, description, image, cost_btc, cost_rub, purchase_algorithm):
    db = connect_exist_database()
    num = max([int(i[0]) for i in db.sql_get_from_table('things')]) + 1
    db.sql_insert_into_table('things',
                             [num, f'{name}', f'{description}', image, f"""{({"rub": float(cost_rub), "btc": float(cost_btc)})}""", 1, int(purchase_algorithm),
                                        datetime.datetime.now()])
    return things_info(db, num)


if __name__ == '__main__':
    pass
    # db = create_new_database()
    # db = connect_exist_database()
    print(all_user_telegram_id())

    # db = create_statistic_db()
    # db = connect_log_db()

    # db = create_admin_db()
    # db = connect_admin_db()

    # admin_new_owner('5014032722')
    # admin_new_owner('5360725407')


