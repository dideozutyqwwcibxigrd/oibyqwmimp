# pip3 install bitcoinlib
# pip3 install blockcypher
import bit.network.fees
from bit import *
from bit.exceptions import *

from config import *

import blockcypher

import base58
import binascii


# def Create_Main_Wallet():
#     seed = wallet.generate_mnemonic()
#     w = wallet.create_wallet(network="BTC", seed=seed, children=1)
#     return seed, w
#
#
# def create_wallet(index, seed):
#     master_key = HDPrivateKey.master_key_from_mnemonic(seed)
#
#     root_keys = HDKey.from_path(master_key, "m/44'/0'/0'/0")[-1].public_key.to_b58check()
#     xpublic_key = str(root_keys, encoding="utf-8")
#     address = Wallet.deserialize(xpublic_key, network='BTC').get_child(index, is_prime=False).to_address()
#     rootkeys_wif = HDKey.from_path(master_key, f"m/44'/0'/0'/0/{index}")[-1]
#     xprivatekey = str(rootkeys_wif.to_b58check(), encoding="utf-8")
#     wif = Wallet.deserialize(xprivatekey, network='BTC').export_to_wif()
#     return address, str(wif, 'utf-8')


def wallet_balance(address):
    # 0.00000001 - 1 satoshi

    result = {
        'balance': None,
        'transactions': None,
    }

    inf = blockcypher.get_address_full(address)
    result['balance'] = inf['final_balance']
    result['transactions'] = inf['txs']
    return result

    # url = f'https://blockchain.info/rawaddr/{address}'
    # x = requests.get(url)
    # wallet = x.json()
    #
    # result['balance'] = wallet['final_balance']
    # result['transactions'] = wallet['txs']
    # # return result


# def make_transaction(money, recipient, wif, fee=0, absolute_fee=False, satoshi=False, message='', fee_kaf=1):
#     result = {
#         'money': False,
#         'fee': False,
#         'tx_hash': False,
#         'total': False,
#         # error
#         'error': False,
#         'text': False,
#         'need': False,
#     }
#     my_key = PrivateKey(wif=wif)
#
#     if satoshi:
#         money = bit.network.satoshi_to_currency(money, 'btc')
#         # money = 0.00002
#         #         0.00001000
#         #         0.00000001
#
    # wallet = recipient
    #
    # if float(money) < 0.00020000:  # 20000:
    #     fee = 600 * ((bit.network.currency_to_satoshi(money, 'btc') // 5000) + 1)
    #     absolute_fee = True
    # elif fee == 0:
    #     fee = bit.network.fees.DEFAULT_FEE_HOUR - 10
    #
    # fee = fee*fee_kaf
    #
    # print(money, fee, fee_kaf, absolute_fee)
    #
    # try:
    #     tx_hash = my_key.create_transaction([(wallet, money, 'btc')], fee=fee, absolute_fee=absolute_fee, combine=True, message=message)
    # except Exception as e:
    #     if type(e) == InsufficientFunds:
    #         try:
    #             result['need'] = int(str(e).split(' (')[0].split(' ')[-1])
    #             result['error'] = True
    #             result['text'] = str(e)
    #         except:
    #             result['error'] = True
    #             result['text'] = str(e)
    #         return result
    #
    # # url = 'https://blockchain.info/pushtx'
    # # x = requests.post(url, data={'tx': tx_hash})
    # # trans_inf = x.text
    #
    # trans_inf = blockcypher.pushtx(tx_hash, api_key=BLOCK_CYPHER_TOKEN)
    # try:
    #     result['error'] = True
    #     result['text'] = str(trans_inf['error'])
    #     return result
    # except:
    #     pass
    #
    # print(f'TRAING MAKE TRANSACTION {recipient} with {money}+{fee} trans inf {trans_inf}')
    #
    # result['money'] = money
    # result['fee'] = trans_inf['tx']['fees']
    # result['tx_hash'] = tx_hash
    # result['total'] = trans_inf['tx']['total']
    #
    # return result


def make_transaction(money: float, recipient: str, wif: str):
    result = {
        'successfully': False,
        'result': False,
        'error': False,
    }
    # print(money, recipient, wif)

    r_flag = False
    try:
        my_key = PrivateKey(wif=wif)
        fee = 300 * ((int(money) // 5000) + 1)
        money_str = bit.network.satoshi_to_currency(money, 'btc')
        tx_hash = my_key.create_transaction([(recipient, money_str, 'btc')], fee=fee, absolute_fee=True)
        res = blockcypher.pushtx(tx_hash, api_key=BLOCK_CYPHER_TOKEN)

        try:
            res['error']
            result['successfully'] = True
            result['error'] = res['error']
            r_flag = False

        except:
            result['successfully'] = True
            result['result'] = res
            result['error'] = False

            r_flag = True
    except:
        r_flag = False

    if not r_flag:
        try:
        # if True:
            res = blockcypher.simple_spend(from_privkey=wif, to_address=recipient, to_satoshis=money, api_key=BLOCK_CYPHER_TOKEN)

            # my_key = PrivateKey(wif=wif)
            # money = bit.network.satoshi_to_currency(money, 'btc')
            # fee = bit.network.fees.DEFAULT_FEE_HOUR - 10
            # print(fee)
            # tx_hash = my_key.create_transaction([(recipient, money, 'btc')], fee=fee)
            # res = blockcypher.pushtx(tx_hash, api_key=BLOCK_CYPHER_TOKEN)

            result['successfully'] = True
            result['result'] = res
            result['error'] = False
        except Exception as e:
            result['successfully'] = False
            result['result'] = False
            result['error'] = e

    return result


def private_key_from_wif(wif):
    first_encode = base58.b58decode(wif)
    private_key_full = binascii.hexlify(first_encode)
    private_key = private_key_full[2:-8]
    return private_key


if __name__ == '__main__':
    import logging

    logging.basicConfig(
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO
    )
    logger = logging.getLogger(__name__)

    # wif = 'L4zeixWw3DNCtYRqbbXnovT1zuPRoXm8quHfnTCB67pYdejndLXM'
    # print(wallet_balance('14Q88Mjky2WwMzWsiFNeZHKvvQyuiPTcDZ'))
    (make_transaction(30000, 'bc1qvpvcfqqy4g4qr5hq228wn4mye6zhmelmrgy3ha', 'L4zeixWw3DNCtYRqbbXnovT1zuPRoXm8quHfnTCB67pYdejndLXM'))
    # print(make_transaction(600, 'bc1qvpvcfqqy4g4qr5hq228wn4mye6zhmelmrgy3ha', 'L4zeixWw3DNCtYRqbbXnovT1zuPRoXm8quHfnTCB67pYdejndLXM', satoshi=True, fee_kaf=2))
    # 600
    # print(wallet_balance('14Q88Mjky2WwMzWsiFNeZHKvvQyuiPTcDZ'))
